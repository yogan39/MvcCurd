﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.ActiveDirectory;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.Net.Mail;
using Excel;

namespace RRF_eReminders.Library
{
    class BusinessLogicClass
    {
        private static string strUserId = string.Empty;

        public BusinessLogicClass(string sUserId)
        {
            strUserId = sUserId;
        }

        #region Common Functions

        public static bool fnLogActivityInFile(string strLogDescription, string strUserId)
        {
            try
            {
                DateTime CD = DateTime.Now;

                string strErrorLogPath = ConfigurationManager.AppSettings["LOG_FILE_PATH"].ToString();
                string strFileName = "Log_" + strUserId + "_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                strFileName = strErrorLogPath + strFileName;

                string sVal = DateTime.Now.ToString() + " : " + strLogDescription;

                StreamWriter sw = new StreamWriter(strFileName, true);
                sw.WriteLine(sVal);
                Console.WriteLine(sVal);
                sw.Flush();
                sw.Close();
            }
            catch (Exception ex)
            {
                //BusinessLogicClass.fnLogErrorInFile(12, "fnLogActivityInFile", ex.Message, strUserId);    //12 as default err code
            }

            return true;
        }

        public static bool fnLogErrorInFile(long lngErrNumber, string strErrLocation, string strErrDescription, string strUserId)
        {
            try
            {
                DateTime CD = DateTime.Now;

                string strErrorLogPath = ConfigurationManager.AppSettings["LOG_FILE_PATH"].ToString();
                string strFileName = "Err_" + strUserId + "_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                strFileName = strErrorLogPath + strFileName;

                StreamWriter sw = new StreamWriter(strFileName, true);
                sw.WriteLine("*******************************************************************************");
                sw.WriteLine("Date: " + DateTime.Now);
                sw.WriteLine("Error Number: " + lngErrNumber.ToString());
                sw.WriteLine("Description: " + strErrDescription);
                sw.WriteLine("Location: " + strErrLocation);
                sw.WriteLine("*******************************************************************************");
                sw.WriteLine();
                sw.Flush();
                sw.Close();
            }
            catch (Exception ex)
            {
                //BusinessLogicClass.fnLogErrorInFile(12, "fnLogErrorInFile", ex.Message, strUserId);    //12 as default err code
            }

            return true;
        }

        public static DataTable fnGetEmailRecipients(string sUnitId, string sRoleId, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UNIT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = sUnitId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@ROLE_ID";
            parm2.DbType = DbType.String;
            parm2.Value = sRoleId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetEmailRecipients", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static bool fnSendEmail(DataTable dtEmailTo, DataTable dtEmailCC, string sEmailSubject, string sEmailBody, string strUserId)
        {
            bool ifOK = false;

            try
            {
                string sSMTPSERVER = ConfigurationManager.AppSettings["SMTP_SERVER"];
                string sEMAILFROM = ConfigurationManager.AppSettings["EMAIL_FROM"];

                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient(sSMTPSERVER);

                mail.From = new MailAddress(sEMAILFROM);

                foreach (DataRow dr in dtEmailTo.Rows)
                {
                    mail.To.Add(dr["USER_EMAIL"].ToString());
                }

                foreach (DataRow dr in dtEmailCC.Rows)
                {
                    mail.CC.Add(dr["USER_EMAIL"].ToString());
                }

                if (ConfigurationManager.AppSettings["SERVER_MODE"].Length > 0)
                    sEmailSubject = "(" + ConfigurationManager.AppSettings["SERVER_MODE"].ToString() + ")" + sEmailSubject;

                //megatshamsul - 20170323 - SR1363674 - add URL to all email notifications
                sEmailBody += "<p>";
                sEmailBody += ConfigurationManager.AppSettings["SITE_ROOT_URL"].ToString() + "/login.aspx";
                
                mail.Subject = sEmailSubject;
                mail.Body = sEmailBody;
                mail.IsBodyHtml = true;

                SmtpServer.Port = 25;
                SmtpServer.Credentials = new System.Net.NetworkCredential(strUserId, "");
                SmtpServer.EnableSsl = false;

                SmtpServer.Send(mail);

                ifOK = true;
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnSendEmail", ex.Message, strUserId);    //12 as default err code
            }

            BusinessLogicClass.fnLogActivityInFile("SEND_EMAIL:" + ifOK.ToString().ToUpper(), strUserId);

            return ifOK;
        }

        public static string TrimExceedLength(string theVal, int theLength)
        {
            string theResult = theVal;

            try
            {
                if (theVal.Length > theLength)
                    theResult = theVal.Substring(0, theLength);
            }
            catch (Exception ex)
            { }

            return theResult;
        }

        #endregion

        #region ACTION_TYPE Functions

        public static bool fnGenESubmissionDueList(string sActionType, string strUserId)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            string sNoOfSet = ConfigurationManager.AppSettings["DEFAULT_ESUBMISSION_TOTAL_SET"].ToString();

            fnLogActivityInFile("DEFAULT_ESUBMISSION_TOTAL_SET:" + sNoOfSet, strUserId);
            
            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@NO_OF_SET";
            parm1.DbType = DbType.String;
            parm1.Value = sNoOfSet;

            SqlParameterList.Add(parm1);

            //additonal sql conditions (if any) for 1b - monthly only
            if (ConfigurationManager.AppSettings["ADD_SQL_CONDITIONS"] != null)
            {
                SqlParameter parm2 = new SqlParameter();
                parm2.ParameterName = "@ADD_SQL_CONDITIONS";
                parm2.DbType = DbType.String;
                parm2.Value = ConfigurationManager.AppSettings["ADD_SQL_CONDITIONS"].ToString();

                SqlParameterList.Add(parm2);
            }

            switch (sActionType)
            {
                case "1": isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspGenAllESubmissions", SqlParameterList, strUserId); break;
                //case "1a": isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspGenAllESubmissionsDailyWeekly", SqlParameterList, strUserId); break;
                case "1a1": isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspGenAllESubmissionsDaily", SqlParameterList, strUserId); break;
                case "1a2": isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspGenAllESubmissionsWeekly", SqlParameterList, strUserId); break;
                case "1b": isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspGenAllESubmissionsMonthly", SqlParameterList, strUserId); break;
                case "1c": isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspGenAllESubmissionsQuarterylyYearly", SqlParameterList, strUserId); break;
                case "1d": isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspGenAllESubmissionsAdHoc6TimesYearly", SqlParameterList, strUserId); break;
            }

            return isOK;
        }

        public static DataTable fnListAlertPendingActionItems(string module_id, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@MODULE_ID";
            parm1.DbType = DbType.String;
            parm1.Value = module_id;

            SqlParameterList.Add(parm1);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListAlertPendingActionItems", SqlParameterList, strUserId);

            return dtDetails;
        }

        //megatshamsul - 20170419 - SR1363674 - send reminder only during working days (KL)
        public static bool fnAllowSendAlerts(string strUserId)
        {
            bool ifOK = false;

            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@DATE_VALUE";
            parm1.DbType = DbType.String;
            parm1.Value = string.Empty; //empty to represent today's date

            SqlParameterList.Add(parm1);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspCheckIfWorkingDays", SqlParameterList, strUserId);

            if (dtDetails.Rows.Count > 0)
            {
                foreach (DataRow drRecord in dtDetails.Rows)
                {
                    if (drRecord["IFWORKINGDAYS"].ToString() == "1")
                        ifOK = true;
                }
            }
            else
                BusinessLogicClass.fnLogErrorInFile(12, "fnAllowSendAlerts", "uspCheckIfWorkingDays returned 0 row", strUserId);    //12 as default err code

            return ifOK;
        }

        public static DataTable fnListAlertPendingSubmissionDue(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListAlertPendingSubmissionDue", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static bool fnSetDormantUsers(string strUserId)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();

            isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspSetDormantUsers", new List<SqlParameter>(), strUserId);

            return isOK;
        }

        public static DataTable fnSendMailtoDormant(string strUserId)// added funtion to get users going to domant in 25 to 30 days- yogan
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetRemainderdormancy", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        #endregion

        #region Load E-Template XLS

        public static DataTable fnReadETemplateXLSFile(string strUserId)
        {
            OleDbConnection objXLSConn = null;
            OleDbDataAdapter objXLSDataAdapter = null;
            OleDbCommand objXLSCmd = new OleDbCommand();
            DataTable dtUpload = new DataTable();
            string sETemplateSheetName = ConfigurationManager.AppSettings["XLS_ETEMPLATE_SHEETNAME"].ToString();

            try
            {
                dtUpload = new DataTable(sETemplateSheetName);
                dtUpload.Columns.Add("SREF", typeof(string));
                dtUpload.Columns.Add("ENTITY_ID", typeof(string));
                dtUpload.Columns.Add("RPT_NAME", typeof(string));
                dtUpload.Columns.Add("REGULATOR_DESC", typeof(string));
                dtUpload.Columns.Add("REGULATORY_DEPT", typeof(string));    //REGULATOR_DEPT
                dtUpload.Columns.Add("SUBMISSION_MODE_DESC", typeof(string));
                dtUpload.Columns.Add("UNIT_ID", typeof(string));
                dtUpload.Columns.Add("REPORT_CONSOLIDATER", typeof(string));
                dtUpload.Columns.Add("REPORT_CONTRIBUTOR1", typeof(string));
                dtUpload.Columns.Add("REPORT_CONTRIBUTOR2", typeof(string));
                dtUpload.Columns.Add("REPORT_CONTRIBUTOR3", typeof(string));
                dtUpload.Columns.Add("REPORT_CONTRIBUTOR4", typeof(string));
                dtUpload.Columns.Add("REMARKS", typeof(string));
                dtUpload.Columns.Add("REGULATOR_ID", typeof(string));
                dtUpload.Columns.Add("SUBMISSION_MODE_ID", typeof(string));
                dtUpload.Columns.Add("FREQUENCY_ID", typeof(string));
                dtUpload.Columns.Add("T_PLUS_SUBMISSION_DATE", typeof(string));
                dtUpload.Columns.Add("BIZ_DAYS_ONLY", typeof(string));
                dtUpload.Columns.Add("date1", typeof(string));
                dtUpload.Columns.Add("date1_SD", typeof(string));
                dtUpload.Columns.Add("date2", typeof(string));
                dtUpload.Columns.Add("date2_SD", typeof(string));
                dtUpload.Columns.Add("date3", typeof(string));
                dtUpload.Columns.Add("date3_SD", typeof(string));
                dtUpload.Columns.Add("date4", typeof(string));
                dtUpload.Columns.Add("date4_SD", typeof(string));
                dtUpload.Columns.Add("date5", typeof(string));
                dtUpload.Columns.Add("date5_SD", typeof(string));
                dtUpload.Columns.Add("date6", typeof(string));
                dtUpload.Columns.Add("date6_SD", typeof(string));
                dtUpload.Columns.Add("date7", typeof(string));
                dtUpload.Columns.Add("date7_SD", typeof(string));
                dtUpload.Columns.Add("date8", typeof(string));
                dtUpload.Columns.Add("date8_SD", typeof(string));
                dtUpload.Columns.Add("date9", typeof(string));
                dtUpload.Columns.Add("date9_SD", typeof(string));
                dtUpload.Columns.Add("date10", typeof(string));
                dtUpload.Columns.Add("date10_SD", typeof(string));
                dtUpload.Columns.Add("date11", typeof(string));
                dtUpload.Columns.Add("date11_SD", typeof(string));
                dtUpload.Columns.Add("date12", typeof(string));
                dtUpload.Columns.Add("date12_SD", typeof(string));

                string sXLSFile = ConfigurationManager.AppSettings["XLS_ETEMPLATE_FILE"].ToString();
                string sExt = Path.GetExtension(sXLSFile).ToUpper();

                if (sExt == ".XLS")
                    objXLSConn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + sXLSFile + ";Extended Properties=\"Excel 8.0;HDR=YES;IMEX=2\"");
                else if (sExt == ".XLSX")
                    objXLSConn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" + sXLSFile + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';");

                objXLSConn.Open();

                objXLSCmd.Connection = objXLSConn;
                objXLSCmd.CommandType = CommandType.Text;

                string sCommandTimeoutVal = ConfigurationManager.AppSettings["CMD_TIMEOUT"];
                int iCommandTimeoutVal = 120;

                if (!string.IsNullOrEmpty(sCommandTimeoutVal))
                    iCommandTimeoutVal = Convert.ToInt16(sCommandTimeoutVal);

                objXLSCmd.CommandTimeout = iCommandTimeoutVal;

                //string strsql = "SELECT * FROM [" + sETemplateSheetName + "$]";
                string strsql = "SELECT SREF,ENTITY_ID,RPT_NAME,REGULATORY_DEPT,UNIT_ID,REPORT_CONSOLIDATER,REPORT_CONTRIBUTOR1,REPORT_CONTRIBUTOR2,REPORT_CONTRIBUTOR3,";
                strsql += "REPORT_CONTRIBUTOR4,REMARKS,REGULATOR_ID,SUBMISSION_MODE_ID,FREQUENCY_ID,T_PLUS_SUBMISSION_DATE,BIZ_DAYS_ONLY,";
                strsql += "date1,date1_SD,date2,date2_SD,date3,date3_SD,date4,date4_SD,date5,date5_SD,date6,date6_SD,";
                strsql += "date7,date7_SD,date8,date8_SD,date9,date9_SD,date10,date10_SD,date11,date11_SD,date12,date12_SD ";
                strsql += "FROM [" + sETemplateSheetName + "$]";

                objXLSCmd.CommandText = strsql;
                objXLSDataAdapter = new OleDbDataAdapter(objXLSCmd);

                objXLSDataAdapter.Fill(dtUpload);

                if (dtUpload.Rows.Count > 0)
                {
                    //remove if it's columns contain either nothing or white space
                    dtUpload = dtUpload.Rows.Cast<DataRow>().Where(row => !row.ItemArray.All(field => field is System.DBNull || string.Compare((field as string).Trim(), string.Empty) == 0)).CopyToDataTable();
                }

            }
            catch (OleDbException dbEx)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnReadETemplateXLSFile", dbEx.Message, strUserId);    //12 as default err code
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnReadETemplateXLSFile", ex.Message, strUserId);    //12 as default err code
            }
            finally
            {
                if (objXLSDataAdapter != null)
                    objXLSDataAdapter.Dispose();

                if (objXLSConn != null)
                {
                    objXLSConn.Close();
                    objXLSConn.Dispose();
                }
            }

            return dtUpload;
        }

        public static DataSet fnReadETemplateXLSFile2(string strUserId)
        {
            DataSet dsExcelFiles = new DataSet();
            IExcelDataReader iExcelDataReader = null;
            
            try
            {
                string sXLSFile = ConfigurationManager.AppSettings["XLS_ETEMPLATE_FILE"].ToString();
                string sExt = Path.GetExtension(sXLSFile).ToUpper();

                FileStream fs = new FileStream(sXLSFile, FileMode.Open, FileAccess.Read);

                if (sExt == ".XLS")
                {
                    iExcelDataReader = ExcelReaderFactory.CreateBinaryReader(fs);
                }
                else if (sExt == ".XLSX")
                {
                    iExcelDataReader = ExcelReaderFactory.CreateOpenXmlReader(fs);
                }

                fs.Dispose();
                //iExcelDataReader.IsFirstRowAsColumnNames = true;
                dsExcelFiles = iExcelDataReader.AsDataSet();
            }
            catch (OleDbException dbEx)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnReadETemplateXLSFile2", dbEx.Message, strUserId);    //12 as default err code
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnReadETemplateXLSFile2", ex.Message, strUserId);    //12 as default err code
            }
            finally
            {

            }

            return dsExcelFiles;
        }

        public static bool fnPrepareETemplateListing(ref DataTable dtDetails, string strUserId)
        {
            bool ifOK = false;

            try
            {
                for (int i = 0; i < dtDetails.Rows.Count; i++)
                {
                    dtDetails.Rows[i]["SREF"] = TrimExceedLength(dtDetails.Rows[i]["SREF"].ToString(), 30);
                    dtDetails.Rows[i]["ENTITY_ID"] = TrimExceedLength(dtDetails.Rows[i]["ENTITY_ID"].ToString(), 30);
                    dtDetails.Rows[i]["RPT_NAME"] = TrimExceedLength(dtDetails.Rows[i]["RPT_NAME"].ToString(), 255);
                    dtDetails.Rows[i]["REGULATOR_DESC"] = TrimExceedLength(dtDetails.Rows[i]["REGULATOR_DESC"].ToString(), 150);
                    dtDetails.Rows[i]["REGULATORY_DEPT"] = TrimExceedLength(dtDetails.Rows[i]["REGULATORY_DEPT"].ToString(), 600);
                    dtDetails.Rows[i]["SUBMISSION_MODE_DESC"] = TrimExceedLength(dtDetails.Rows[i]["SUBMISSION_MODE_DESC"].ToString(), 150);
                    dtDetails.Rows[i]["UNIT_ID"] = TrimExceedLength(dtDetails.Rows[i]["UNIT_ID"].ToString(), 50);
                    dtDetails.Rows[i]["REPORT_CONSOLIDATER"] = TrimExceedLength(dtDetails.Rows[i]["REPORT_CONSOLIDATER"].ToString(), 50);
                    dtDetails.Rows[i]["REPORT_CONTRIBUTOR1"] = TrimExceedLength(dtDetails.Rows[i]["REPORT_CONTRIBUTOR1"].ToString(), 50);
                    dtDetails.Rows[i]["REPORT_CONTRIBUTOR2"] = TrimExceedLength(dtDetails.Rows[i]["REPORT_CONTRIBUTOR2"].ToString(), 50);
                    dtDetails.Rows[i]["REPORT_CONTRIBUTOR3"] = TrimExceedLength(dtDetails.Rows[i]["REPORT_CONTRIBUTOR3"].ToString(), 50);
                    dtDetails.Rows[i]["REPORT_CONTRIBUTOR4"] = TrimExceedLength(dtDetails.Rows[i]["REPORT_CONTRIBUTOR4"].ToString(), 50);
                    dtDetails.Rows[i]["REMARKS"] = TrimExceedLength(dtDetails.Rows[i]["REMARKS"].ToString(), 50);
                    dtDetails.Rows[i]["REGULATOR_ID"] = TrimExceedLength(dtDetails.Rows[i]["REGULATOR_ID"].ToString(), 3);
                    dtDetails.Rows[i]["SUBMISSION_MODE_ID"] = TrimExceedLength(dtDetails.Rows[i]["SUBMISSION_MODE_ID"].ToString(), 3);
                    dtDetails.Rows[i]["FREQUENCY_ID"] = TrimExceedLength(dtDetails.Rows[i]["FREQUENCY_ID"].ToString(), 30);
                    dtDetails.Rows[i]["T_PLUS_SUBMISSION_DATE"] = TrimExceedLength(dtDetails.Rows[i]["T_PLUS_SUBMISSION_DATE"].ToString(), 5);
                    dtDetails.Rows[i]["BIZ_DAYS_ONLY"] = TrimExceedLength(dtDetails.Rows[i]["BIZ_DAYS_ONLY"].ToString(), 15);
                    dtDetails.Rows[i]["date1"] = TrimExceedLength(dtDetails.Rows[i]["date1"].ToString(), 30);
                    dtDetails.Rows[i]["date1_SD"] = TrimExceedLength(dtDetails.Rows[i]["date1_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date2"] = TrimExceedLength(dtDetails.Rows[i]["date2"].ToString(), 30);
                    dtDetails.Rows[i]["date2_SD"] = TrimExceedLength(dtDetails.Rows[i]["date2_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date3"] = TrimExceedLength(dtDetails.Rows[i]["date3"].ToString(), 30);
                    dtDetails.Rows[i]["date3_SD"] = TrimExceedLength(dtDetails.Rows[i]["date3_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date4"] = TrimExceedLength(dtDetails.Rows[i]["date4"].ToString(), 30);
                    dtDetails.Rows[i]["date4_SD"] = TrimExceedLength(dtDetails.Rows[i]["date4_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date5"] = TrimExceedLength(dtDetails.Rows[i]["date5"].ToString(), 30);
                    dtDetails.Rows[i]["date5_SD"] = TrimExceedLength(dtDetails.Rows[i]["date5_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date6"] = TrimExceedLength(dtDetails.Rows[i]["date6"].ToString(), 30);
                    dtDetails.Rows[i]["date6_SD"] = TrimExceedLength(dtDetails.Rows[i]["date6_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date7"] = TrimExceedLength(dtDetails.Rows[i]["date7"].ToString(), 30);
                    dtDetails.Rows[i]["date7_SD"] = TrimExceedLength(dtDetails.Rows[i]["date7_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date8"] = TrimExceedLength(dtDetails.Rows[i]["date8"].ToString(), 30);
                    dtDetails.Rows[i]["date8_SD"] = TrimExceedLength(dtDetails.Rows[i]["date8_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date9"] = TrimExceedLength(dtDetails.Rows[i]["date9"].ToString(), 30);
                    dtDetails.Rows[i]["date9_SD"] = TrimExceedLength(dtDetails.Rows[i]["date9_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date10"] = TrimExceedLength(dtDetails.Rows[i]["date10"].ToString(), 30);
                    dtDetails.Rows[i]["date10_SD"] = TrimExceedLength(dtDetails.Rows[i]["date10_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date11"] = TrimExceedLength(dtDetails.Rows[i]["date11"].ToString(), 30);
                    dtDetails.Rows[i]["date11_SD"] = TrimExceedLength(dtDetails.Rows[i]["date11_SD"].ToString(), 30);
                    dtDetails.Rows[i]["date12"] = TrimExceedLength(dtDetails.Rows[i]["date12"].ToString(), 30);
                    dtDetails.Rows[i]["date12_SD"] = TrimExceedLength(dtDetails.Rows[i]["date12_SD"].ToString(), 30);
                }

                ifOK = true;
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnPrepareETemplateListing", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        public static bool fnPrepareETemplateListing2(DataSet dsDetails, ref DataTable dtUpload, string strUserId)
        {
            bool ifOK = false;

            try
            {
                foreach (DataTable dt in dsDetails.Tables)
                {
                    if (ConfigurationManager.AppSettings["XLS_ETEMPLATE_SHEETNAME"].ToString() == dt.ToString().ToUpper())
                    {
                        int iFirstRowsToSkip = 1;
                        int iColToAccept = 42;
                        int x = 0;
                        int y = 0;
                        DataRow row;

                        foreach (DataRow dr in dt.Rows)
                        {
                            if (x >= iFirstRowsToSkip)
                            {
                                row = dtUpload.NewRow();
                                y = 0;

                                foreach (var item in dr.ItemArray) // Loop over the items.
                                {
                                    if (y <= iColToAccept)
                                    {
                                        switch (y)
                                        {
                                            case 0: row["SREF"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 1: row["ENTITY_ID"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 2: row["RPT_NAME"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 255); break;
                                            case 3: row["REGULATOR_DESC"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 150); break;
                                            case 4: row["REGULATORY_DEPT"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 600); break;
                                            case 5: row["SUBMISSION_MODE_DESC"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 150); break;
                                            case 6: row["UNIT_ID"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 7: row["REPORT_CONSOLIDATER"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 8: row["REPORT_CONTRIBUTOR1"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 9: row["REPORT_CONTRIBUTOR2"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 10: row["REPORT_CONTRIBUTOR3"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 11: row["REPORT_CONTRIBUTOR4"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 12: row["REMARKS"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            
                                            case 13: 
                                                if (item.ToString().Length >= 4)
                                                    row["REGULATOR_ID"] = TrimExceedLength(item.ToString().Substring(1, 3).TrimStart().TrimEnd(), 3);   //remove additional "'" in front
                                                else
                                                    row["REGULATOR_ID"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 3); 
                                                break;
                                            
                                            case 14:
                                                if (item.ToString().Length >= 4)
                                                    row["SUBMISSION_MODE_ID"] = TrimExceedLength(item.ToString().Substring(1, 3).TrimStart().TrimEnd(), 3); //remove additional "'" in front
                                                else
                                                    row["SUBMISSION_MODE_ID"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 3);
                                                break;   

                                            case 15: row["FREQUENCY_ID"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 16: row["T_PLUS_SUBMISSION_DATE"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 5); break;
                                            case 17: row["BIZ_DAYS_ONLY"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 15); break;
                                            case 18: row["date1"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 19: row["date1_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 20: row["date2"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 21: row["date2_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 22: row["date3"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 23: row["date3_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 24: row["date4"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 25: row["date4_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 26: row["date5"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 27: row["date5_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 28: row["date6"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 29: row["date6_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 30: row["date7"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 31: row["date7_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 32: row["date8"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 33: row["date8_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 34: row["date9"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 35: row["date9_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 36: row["date10"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 37: row["date10_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 38: row["date11"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 39: row["date11_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 40: row["date12"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 41: row["date12_SD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                        }
                                    }
                                    y++;
                                }
                                dtUpload.Rows.Add(row);
                            }
                            x++;
                        }

                        ifOK = true;
                    }
                }
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnPrepareETemplateListing2", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        public static bool fnLoadETemplateListing(DataTable dtDetails, string strUserId)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter("@DATA_DETAILS", SqlDbType.Structured);
            parm1.Value = dtDetails;
            parm1.Direction = ParameterDirection.Input;
            
            SqlParameterList.Add(parm1);

            isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspLoadETemplateListing", SqlParameterList, strUserId);

            return isOK;
        }

        #endregion

        #region Load User Listing XLS

        public static DataTable fnReadUserListingXLSFile(string strUserId)
        {
            OleDbConnection objXLSConn = null;
            OleDbDataAdapter objXLSDataAdapter = null;
            OleDbCommand objXLSCmd = new OleDbCommand();
            DataTable dtUpload = new DataTable();
            string sETemplateSheetName = ConfigurationManager.AppSettings["XLS_USERLISTING_SHEETNAME"].ToString();

            try
            {
                dtUpload = new DataTable(sETemplateSheetName);
                dtUpload.Columns.Add("USER_ID", typeof(string));
                dtUpload.Columns.Add("DOMAIN_ID", typeof(string));
                dtUpload.Columns.Add("USER_NAME", typeof(string));
                dtUpload.Columns.Add("LOB", typeof(string));
                dtUpload.Columns.Add("DEPT", typeof(string));
                dtUpload.Columns.Add("HOD", typeof(string));
                dtUpload.Columns.Add("UNIT", typeof(string));
                dtUpload.Columns.Add("ROLE", typeof(string));
                dtUpload.Columns.Add("EMP_ID", typeof(string));
                dtUpload.Columns.Add("USER_EMAIL", typeof(string));
                dtUpload.Columns.Add("IP_ADDRESS", typeof(string));
                
                string sXLSFile = ConfigurationManager.AppSettings["XLS_USERLISTING_FILE"].ToString();
                string sExt = Path.GetExtension(sXLSFile).ToUpper();

                if (sExt == ".XLS")
                    objXLSConn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + sXLSFile + ";Extended Properties=\"Excel 8.0;HDR=YES;IMEX=2\"");
                else if (sExt == ".XLSX")
                    objXLSConn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" + sXLSFile + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';");

                objXLSConn.Open();

                objXLSCmd.Connection = objXLSConn;
                objXLSCmd.CommandType = CommandType.Text;

                string sCommandTimeoutVal = ConfigurationManager.AppSettings["CMD_TIMEOUT"];
                int iCommandTimeoutVal = 120;

                if (!string.IsNullOrEmpty(sCommandTimeoutVal))
                    iCommandTimeoutVal = Convert.ToInt16(sCommandTimeoutVal);

                objXLSCmd.CommandTimeout = iCommandTimeoutVal;

                //string strsql = "SELECT * FROM [" + sETemplateSheetName + "$]";
                string strsql = "SELECT USER_ID,DOMAIN_ID,USER_NAME,LOB,DEPT,HOD,UNIT,ROLE,EMP_ID,USER_EMAIL,IP_ADDRESS ";
                strsql += "FROM [" + sETemplateSheetName + "$]";

                objXLSCmd.CommandText = strsql;
                objXLSDataAdapter = new OleDbDataAdapter(objXLSCmd);

                objXLSDataAdapter.Fill(dtUpload);

                if (dtUpload.Rows.Count > 0)
                {
                    //remove if it's columns contain either nothing or white space
                    dtUpload = dtUpload.Rows.Cast<DataRow>().Where(row => !row.ItemArray.All(field => field is System.DBNull || string.Compare((field as string).Trim(), string.Empty) == 0)).CopyToDataTable();
                }

            }
            catch (OleDbException dbEx)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnReadUserListingXLSFile", dbEx.Message, strUserId);    //12 as default err code
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnReadUserListingXLSFile", ex.Message, strUserId);    //12 as default err code
            }
            finally
            {
                if (objXLSDataAdapter != null)
                    objXLSDataAdapter.Dispose();

                if (objXLSConn != null)
                {
                    objXLSConn.Close();
                    objXLSConn.Dispose();
                }
            }

            return dtUpload;
        }

        public static DataSet fnReadUserListingXLSFile2(string strUserId)
        {
            DataSet dsExcelFiles = new DataSet();
            IExcelDataReader iExcelDataReader = null;
            
            try
            {
                string sXLSFile = ConfigurationManager.AppSettings["XLS_USERLISTING_FILE"].ToString();
                string sExt = Path.GetExtension(sXLSFile).ToUpper();

                FileStream fs = new FileStream(sXLSFile, FileMode.Open, FileAccess.Read);

                if (sExt == ".XLS")
                {
                    iExcelDataReader = ExcelReaderFactory.CreateBinaryReader(fs);
                }
                else if (sExt == ".XLSX")
                {
                    iExcelDataReader = ExcelReaderFactory.CreateOpenXmlReader(fs);
                }

                fs.Dispose();
                //iExcelDataReader.IsFirstRowAsColumnNames = true;
                dsExcelFiles = iExcelDataReader.AsDataSet();
            }
            catch (OleDbException dbEx)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnReadUserListingXLSFile2", dbEx.Message, strUserId);    //12 as default err code
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnReadUserListingXLSFile2", ex.Message, strUserId);    //12 as default err code
            }
            finally
            {

            }

            return dsExcelFiles;
        }

        public static bool fnPrepareUserListing(ref DataTable dtDetails, string strUserId)
        {
            bool ifOK = false;

            try
            {
                for (int i = 0; i < dtDetails.Rows.Count; i++)
                {
                    dtDetails.Rows[i]["USER_ID"] = TrimExceedLength(dtDetails.Rows[i]["USER_ID"].ToString(), 30);
                    dtDetails.Rows[i]["DOMAIN_ID"] = TrimExceedLength(dtDetails.Rows[i]["DOMAIN_ID"].ToString(), 50);
                    dtDetails.Rows[i]["USER_NAME"] = TrimExceedLength(dtDetails.Rows[i]["USER_NAME"].ToString(), 100);
                    dtDetails.Rows[i]["LOB"] = TrimExceedLength(dtDetails.Rows[i]["LOB"].ToString(), 50);
                    dtDetails.Rows[i]["DEPT"] = TrimExceedLength(dtDetails.Rows[i]["DEPT"].ToString(), 50);
                    dtDetails.Rows[i]["HOD"] = TrimExceedLength(dtDetails.Rows[i]["HOD"].ToString(), 100);
                    dtDetails.Rows[i]["UNIT"] = TrimExceedLength(dtDetails.Rows[i]["UNIT"].ToString(), 50);
                    dtDetails.Rows[i]["ROLE"] = TrimExceedLength(dtDetails.Rows[i]["ROLE"].ToString(), 10);
                    dtDetails.Rows[i]["EMP_ID"] = TrimExceedLength(dtDetails.Rows[i]["EMP_ID"].ToString(), 50);
                    dtDetails.Rows[i]["USER_EMAIL"] = TrimExceedLength(dtDetails.Rows[i]["USER_EMAIL"].ToString(), 100);
                    dtDetails.Rows[i]["IP_ADDRESS"] = TrimExceedLength(dtDetails.Rows[i]["IP_ADDRESS"].ToString(), 16);
                }

                ifOK = true;
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnPrepareUserListing", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        public static bool fnPrepareUserListing2(DataSet dsDetails, ref DataTable dtUpload, string strUserId)
        {
            bool ifOK = false;

            try
            {
                foreach (DataTable dt in dsDetails.Tables)
                {
                    if (ConfigurationManager.AppSettings["XLS_USERLISTING_SHEETNAME"].ToString() == dt.ToString().ToUpper())
                    {
                        int iFirstRowsToSkip = 1;
                        int iColToAccept = 11;
                        int x = 0;
                        int y = 0;
                        DataRow row;

                        foreach (DataRow dr in dt.Rows)
                        {
                            if (x >= iFirstRowsToSkip)
                            {
                                row = dtUpload.NewRow();
                                y = 0;

                                foreach (var item in dr.ItemArray) // Loop over the items.
                                {
                                    if (y <= iColToAccept)
                                    {
                                        switch (y)
                                        {
                                            case 0: row["USER_ID"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 30); break;
                                            case 1: row["DOMAIN_ID"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 2: row["USER_NAME"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 100); break;
                                            case 3: row["LOB"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 4: row["DEPT"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 5: row["HOD"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 100); break;
                                            case 6: row["UNIT"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 7: row["ROLE"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 10); break;
                                            case 8: row["EMP_ID"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 50); break;
                                            case 9: row["USER_EMAIL"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 100); break;
                                            case 10: row["IP_ADDRESS"] = TrimExceedLength(item.ToString().TrimStart().TrimEnd(), 16); break;
                                        }
                                    }
                                    y++;
                                }
                                dtUpload.Rows.Add(row);
                            }
                            x++;
                        }

                        ifOK = true;
                    }
                }
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnPrepareUserListing2", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        public static bool fnLoadUserListing(DataTable dtDetails, string strUserId)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter("@DATA_DETAILS", SqlDbType.Structured);
            parm1.Value = dtDetails;
            parm1.Direction = ParameterDirection.Input;

            SqlParameterList.Add(parm1);

            isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspLoadUserListing", SqlParameterList, strUserId);

            return isOK;
        }

        #endregion
    }
}
