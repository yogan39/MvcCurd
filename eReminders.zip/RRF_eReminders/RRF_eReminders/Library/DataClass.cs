﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using RRF_eReminders.Library;

namespace RRF_eReminders.Library
{
    class DataClass
    {
        // This constant string is used as a "salt" value for the PasswordDeriveBytes function calls.
        // This size of the IV (in bytes) must = (keysize / 8).  Default keysize is 256, so the IV must be
        // 32 bytes long.  Using a 16 character string here gives us 32 bytes when converted to a byte array.
        private const string initVector = "tu89geji340t89u2";

        // This constant is used to determine the keysize of the encryption algorithm.
        private const int keysize = 256;

        private const string thePassword = "B5DaTy4I";

        private SqlConnection objSQLConnection = new SqlConnection();
        private string strDBConnection = String.Empty;

        private string fnGetDBConnectionString()
        {
            string DBSERVER = ConfigurationManager.AppSettings["DB_SERVER"].ToString();
            string DBNAME = ConfigurationManager.AppSettings["DB_NAME"].ToString();
            string DBUSERID = ConfigurationManager.AppSettings["DB_USER_ID"].ToString();
            string DBUSERPWD = Decrypt(ConfigurationManager.AppSettings["DB_USER_PWD"].ToString());
            string MAXPOOLSIZE = ConfigurationManager.AppSettings["MAX_POOL_SIZE"].ToString();
            string CON_TIMEOUT = ConfigurationManager.AppSettings["CON_TIMEOUT"].ToString();
            string INTEGRATEDSEC = ConfigurationManager.AppSettings["DB_INTEGRATED_SEC"].ToString();

            return "Server=" + DBSERVER + "; Database=" + DBNAME + ";User Id=" + DBUSERID + ";Password=" + DBUSERPWD + "; Integrated Security=" + INTEGRATEDSEC + "; Max Pool Size=" + MAXPOOLSIZE + "; Connection Timeout=" + CON_TIMEOUT + ";";
        }

        private bool fnOpenConnectionDB()
        {
            string strMessage = string.Empty;
            bool bResult = false;

            try
            {
                if (objSQLConnection.State != ConnectionState.Open)
                {
                    objSQLConnection.ConnectionString = fnGetDBConnectionString();
                    objSQLConnection.Open();
                    bResult = true;
                }
                else
                    bResult = false;
            }
            catch (SqlException dbEx)
            {
                strMessage = dbEx.Message;
            }
            catch (Exception ex)
            {
                strMessage = ex.Message;
            }

            return bResult;
        }

        private bool fnCloseConnectionDB()
        {
            string strMessage = string.Empty;
            bool bResult = false;

            try
            {
                if (objSQLConnection.State != ConnectionState.Closed)
                {
                    objSQLConnection.Close();
                    bResult = true;
                }
            }
            catch (SqlException dbEx)
            {
                strMessage = dbEx.Message;
            }
            catch (Exception ex)
            {
                strMessage = ex.Message;
            }
            return bResult;
        }

        public DataTable fnReturnDataTable(string strCommandType, string strQuery, List<SqlParameter> Parameters, string strUserId)
        {
            SqlCommand objSQLCommand = null;
            SqlDataAdapter objSQLDataAdapter = null;
            string strSQLCommand = string.Empty;
            DataTable objDataTable = new DataTable();

            try
            {
                string sCommandTimeoutVal = ConfigurationManager.AppSettings["CMD_TIMEOUT"];
                int iCommandTimeoutVal = 120;

                if (!string.IsNullOrEmpty(sCommandTimeoutVal))
                    iCommandTimeoutVal = Convert.ToInt16(sCommandTimeoutVal);

                if (fnOpenConnectionDB())
                {
                    objSQLCommand = new SqlCommand();
                    objSQLDataAdapter = new SqlDataAdapter();

                    objSQLCommand.Connection = objSQLConnection;
                    objSQLCommand.CommandText = strQuery;

                    if (strCommandType == "P")
                        objSQLCommand.CommandType = CommandType.StoredProcedure;

                    objSQLDataAdapter.SelectCommand = objSQLCommand;

                    if (Parameters != null && Parameters.Count >= 1)
                    {
                        foreach (SqlParameter objParameter in Parameters)
                        {
                            objSQLCommand.Parameters.Add(objParameter);
                        }
                    }

                    objSQLDataAdapter.Fill(objDataTable);
                    return objDataTable;
                }
                else
                    return objDataTable;
            }
            catch (SqlException dbEx)
            {
                BusinessLogicClass.fnLogErrorInFile(dbEx.ErrorCode, strQuery, dbEx.Message, strUserId);
                return objDataTable;
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, strQuery, ex.Message, strUserId);    //12 as default err code
                return objDataTable;
            }
            finally
            {
                objDataTable = null;
                objSQLDataAdapter = null;
                objSQLCommand = null;
                fnCloseConnectionDB();
            }
        }

        public bool fnExecuteNonQuery(string strCommandType, string strQuery, List<SqlParameter> Parameters, string strUserId)
        {
            SqlCommand objSQLCommand = null;
            string strSQLCommand = string.Empty;
            bool isOK = false;

            try
            {
                string sCommandTimeoutVal = ConfigurationManager.AppSettings["CMD_TIMEOUT"];
                int iCommandTimeoutVal = 120;

                if (!string.IsNullOrEmpty(sCommandTimeoutVal))
                    iCommandTimeoutVal = Convert.ToInt16(sCommandTimeoutVal);

                if (fnOpenConnectionDB())
                {
                    objSQLCommand = new SqlCommand(strQuery);

                    objSQLCommand.Connection = objSQLConnection;
                    objSQLCommand.CommandText = strQuery;

                    if (strCommandType == "P")
                        objSQLCommand.CommandType = CommandType.StoredProcedure;

                    if (Parameters != null && Parameters.Count >= 1)
                    {
                        foreach (SqlParameter objParameter in Parameters)
                        {
                            objSQLCommand.Parameters.Add(objParameter);
                        }
                    }

                    objSQLCommand.ExecuteNonQuery();

                    isOK = true;
                }
            }
            catch (SqlException dbEx)
            {
                BusinessLogicClass.fnLogErrorInFile(dbEx.ErrorCode, strQuery, dbEx.Message, strUserId);
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, strQuery, ex.Message, strUserId);    //12 as default err code
            }
            finally
            {
                objSQLCommand = null;
                fnCloseConnectionDB();
            }

            return isOK;
        }

        public static string Encrypt(string plainText)
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(thePassword, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        public static string Decrypt(string cipherText)
        {
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(thePassword, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
        }

    }
}
