﻿using RRFGUI.Library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RRFGUI.Management
{
    public partial class UnitCode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "UnitCode";
            if(!IsPostBack)
            {
                TabContainerUnitMaintenance.ActiveTab = TabPanelListing;
                switch (Session["strRoleId"].ToString())
                {
                    case "Admin":
                        btnNew.Visible = true;
                        DDlistUnit.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
                        DDlistUnit.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDlistUnit.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        break;

                    case "AdminAA":
                        btnNew.Visible = false;
                        DDlistUnit.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
                        DDlistUnit.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDlistUnit.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        DDlistUnit.Items.Add(new System.Web.UI.WebControls.ListItem("Pending", "P"));
                        break;
                }
                fnBindUnit(false);
            }
            fnLoadDeptCode();
     }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strUnitId = grdvwListing.SelectedRow.Cells[1].Text;
            string strDeptId = grdvwListing.SelectedRow.Cells[3].Text;
            string strMessage = string.Empty;
            strMessage = fnEnableforEdit(strUnitId, strDeptId);

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {
           
        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindUnit(false);
            fnLoadDeptCode();
        }

        protected void grdvwListing_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
        private void fnBindUnit(bool isExport)
        {
            txtUnitcode.Text = string.Empty;
            txtUNIT_NAME.Text = string.Empty;
            ddlDEPT_NAME.Items.Clear();
            txtREJECT_REASON.Text = string.Empty;
            TabContainerUnitMaintenance.ActiveTab = TabPanelListing;
            string strroleid = Session["strRoleId"].ToString();
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadUNIT(strroleid, Session["strUserId"].ToString(), txtFilterUnit_name.Text.ToString(), isExport, DDlistUnit.SelectedValue);
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();
        }


        private string fnEnableforEdit(string strUnitId, string strDeptcode)
        {
            string strMessage = string.Empty;
            string strstatus = string.Empty;
            TabContainerUnitMaintenance.ActiveTab = TabPanelDetails;
            if (TabContainerUnitMaintenance.ActiveTabIndex == 1)
            {
                System.Web.UI.WebControls.ListItem oListItem;

                DataTable dtCodeDetails = BusinessLogicClass.fnGetlistUNIT(strUnitId, Session["strUserId"].ToString(), strDeptcode);

                if (dtCodeDetails.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtCodeDetails.Rows)
                    {
                        txtUnitcode.Text = dr["UNIT_CODE"].ToString();
                        txtUNIT_NAME.Text = dr["UNIT_CODE_NM"].ToString();
                        txtREJECT_REASON.Text = dr["REJECT_REASON"].ToString();
                        strstatus = dr["STATUS"].ToString();
                        oListItem = ddlDEPT_NAME.Items.FindByValue(dr["DEPT_CODE"].ToString());
                        if (oListItem != null)
                            ddlDEPT_NAME.SelectedValue = oListItem.Value;
                    }

                }
                else
                {
                    strMessage = "No record found";
                }

                fnEnablecntrlforEdit(strstatus);
            }
            return strMessage;
        }

        private void fnEnablecntrlforEdit(string strststus)
        {
            switch (Session["strRoleId"].ToString())
            {
                case "Admin":
                    lblDepNO.Visible = true;
                    txtUnitcode.Visible = true;
                    txtUNIT_NAME.Enabled = true;
                    ddlDEPT_NAME.Enabled = false;
                    btnUpdate.Visible = true;
                    btnAprove.Visible = false;
                    btnCreate.Visible = false;
                    break;

                case "AdminAA":

                    btnReject.Visible = true;
                    lblDepNO.Visible = true;
                    txtUnitcode.Visible = true;
                    txtREJECT_REASON.Enabled = true;

                    if (strststus == "A")
                    {
                        btnAprove.Visible = false;
                    }
                    else
                    {
                        btnAprove.Visible = true;
                    }
                    btnReject.Visible = true;
                    break;
            }
        }

        private void fnLoadDeptCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadDEPTCode(Session["strUserId"].ToString());

            ddlDEPT_NAME.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlDEPT_NAME.Items.Add(new System.Web.UI.WebControls.ListItem(dr["DEPT_CODE_NM"].ToString(), dr["DEPT_CODE"].ToString()));
            }
        }

        [WebMethod]
        public static List<string> fnSerchUnitName(string prefixText, int count)// tested ok yogan.
        {
            string ssuserid = HttpContext.Current.Session["strUserId"].ToString();
            string ssrole = HttpContext.Current.Session["strRoleId"].ToString();

            DataTable dtCodeDetails = BusinessLogicClass.fnLoadUNIT(ssrole, ssuserid, prefixText, true, string.Empty); //Yogan Added Search by Name according to SR''

            List<string> LOB_NAME = new List<string>();

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                LOB_NAME.Add(dr["UNIT_CODE_NM"].ToString());
            }
            return LOB_NAME;
        }

        public bool fnvalidate()
        {
            if (string.IsNullOrEmpty(txtUNIT_NAME.Text))
            {
                ShowMessage("Please enter DEPT_NAME", txtUNIT_NAME.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlDEPT_NAME.SelectedValue))
            {
                ShowMessage("Please select LOB_NAME", ddlDEPT_NAME.ClientID.ToString());
                return false;
            }
            return true;
        }

        protected void btnListRefresh_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtFilterUnit_name.Text) && !string.IsNullOrEmpty(DDlistUnit.SelectedValue))
            {
                ShowMessage("Please Choose one Filter Mode", txtFilterUnit_name.ClientID.ToString());
            }
            else
            {
                fnBindUnit(true);
            }
        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            TabContainerUnitMaintenance.ActiveTab = TabPanelDetails;
            txtUNIT_NAME.Text = string.Empty;
            ddlDEPT_NAME.Text = string.Empty;
            lblDepNO.Visible = false;
            txtUnitcode.Visible = false;
            txtUNIT_NAME.Enabled = true;     
            ddlDEPT_NAME.Enabled = true;
            btnCreate.Visible = true;
            btnUpdate.Visible = false;
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateUNIT("I", "", Session["strUserId"].ToString(), "", txtUNIT_NAME.Text.ToString(), ddlDEPT_NAME.SelectedValue.ToString()), string.Empty);
                fnBindUnit(false);
            }
        }

        protected void btnAprove_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateUNIT("A", "", Session["strUserId"].ToString(), txtUnitcode.Text.ToString(), txtUNIT_NAME.Text.ToString(), ddlDEPT_NAME.SelectedValue.ToString()), string.Empty);
                fnBindUnit(false);
            }
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                if (string.IsNullOrEmpty(txtREJECT_REASON.Text))
                {
                    ShowMessage("Please select REJECT_REASON", txtREJECT_REASON.ClientID.ToString());
                }
                else
                {
                    ShowMessage(BusinessLogicClass.fnupdateUNIT("R", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtUnitcode.Text.ToString(), txtUNIT_NAME.Text.ToString(), ddlDEPT_NAME.SelectedValue.ToString()), string.Empty);
                    fnBindUnit(false);
                }
            }

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateUNIT("U", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtUnitcode.Text.ToString(), txtUNIT_NAME.Text.ToString(),ddlDEPT_NAME.SelectedValue.ToString()), string.Empty);
                fnBindUnit(false);
            }
        }
    }
}