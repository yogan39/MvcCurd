﻿using RRFGUI.Library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RRFGUI.Management
{
    public partial class SubmissionModeCode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "SubmissionMode Code";
            if (!IsPostBack)
            {
                TabContainerSub_ModeMaintenance.ActiveTab = TabPanelListing;
                switch (Session["strRoleId"].ToString())
                {
                    case "Admin":
                        btToAdd.Visible = true;
                        DDSubModeList.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
                        DDSubModeList.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDSubModeList.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        break;

                    case "AdminAA":
                        btToAdd.Visible = false;
                        DDSubModeList.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
                        DDSubModeList.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDSubModeList.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        DDSubModeList.Items.Add(new System.Web.UI.WebControls.ListItem("Pending", "P"));
                        break;
                }
                fnBindSubMode(false);
            }
        }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindSubMode(false);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdvwListing_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strRagulatorId = grdvwListing.SelectedRow.Cells[1].Text;


            string strMessage = string.Empty;
            strMessage = fnEnableforEdit(strRagulatorId);

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        private void fnBindSubMode(bool isExport)
        {
            txtSubmModeID.Text = string.Empty;
            txtSubmModeName.Text = string.Empty;
            txtREJECT_REASON.Text = string.Empty;
            TabContainerSub_ModeMaintenance.ActiveTab = TabPanelListing;
            string strroleid = Session["strRoleId"].ToString();
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadSUBMODE(strroleid, Session["strUserId"].ToString(), txtfilterSubmode.Text.ToString(), isExport, DDSubModeList.SelectedValue);
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();
            txtfilterSubmode.Text = string.Empty;
        }

        private string fnEnableforEdit(string strCateId)
        {
            string strMessage = string.Empty;
            string strstatus = string.Empty;

            TabContainerSub_ModeMaintenance.ActiveTab = TabPanelDetails;
            if (TabContainerSub_ModeMaintenance.ActiveTabIndex == 1)
            {

                DataTable dtCodeDetails = BusinessLogicClass.fnGetlistSUBMODE(strCateId, Session["strUserId"].ToString());

                if (dtCodeDetails.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtCodeDetails.Rows)
                    {
                        txtSubmModeID.Text = dr["SUBMISSION_MODE_ID"].ToString();
                        txtSubmModeName.Text = dr["SUBMISSION_MODE_DESC"].ToString();
                        txtREJECT_REASON.Text = dr["REJECT_REASON"].ToString();
                        strstatus = dr["STATUS"].ToString();
                    }
                }
                else
                {
                    strMessage = "No record found";
                }

                fnEnablecntrlforEdit(strstatus);
            }

            return strMessage;
        }

        private void fnEnablecntrlforEdit(string strststus)
        {
            switch (Session["strRoleId"].ToString())
            {
                case "Admin":
                    lblSubModecode.Visible = true;
                    txtSubmModeID.Visible = true;
                    txtSubmModeName.Enabled = true;
                    btnUpdate.Visible = true;
                    btnAprove.Visible = false;
                    btnCreate.Visible = false;
                    break;

                case "AdminAA":

                    btnReject.Visible = true;
                    lblSubModecode.Visible = true;
                    txtSubmModeID.Visible = true;
                    txtREJECT_REASON.Enabled = true;

                    if (strststus == "A")
                    {
                        btnAprove.Visible = false;
                    }
                    else
                    {
                        btnAprove.Visible = true;
                    }
                    btnReject.Visible = true;
                    break;
            }
        }

        public bool fnvalidate()
        {
            if (string.IsNullOrEmpty(txtSubmModeName.Text))
            {
                ShowMessage("Please enter SUBMISSON_MODE_NAME", txtSubmModeName.ClientID.ToString());
                return false;
            }

            return true;
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtfilterSubmode.Text) && !string.IsNullOrEmpty(DDSubModeList.SelectedValue))
            {
                ShowMessage("Please Choose one Filter Mode", txtfilterSubmode.ClientID.ToString());
            }
            else
            {
                fnBindSubMode(true);
            }
        }

        protected void btToAdd_Click(object sender, EventArgs e)
        {
            TabContainerSub_ModeMaintenance.ActiveTab = TabPanelDetails;
            txtSubmModeName.Text = string.Empty;
            lblSubModecode.Visible = false;
            txtSubmModeID.Visible = false;
            txtSubmModeName.Enabled = true;
            btnCreate.Visible = true;
            btnUpdate.Visible = false;
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateSUBMODE("I", "", Session["strUserId"].ToString(), "", txtSubmModeName.Text.ToString()), string.Empty);
                fnBindSubMode(false);
            }
        }

        protected void btnAprove_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateSUBMODE("A", "", Session["strUserId"].ToString(), txtSubmModeID.Text.ToString(), txtSubmModeName.Text.ToString()), string.Empty);
                fnBindSubMode(false);
            }
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                if (string.IsNullOrEmpty(txtREJECT_REASON.Text))
                {
                    ShowMessage("Please select REJECT_REASON", txtREJECT_REASON.ClientID.ToString());
                }
                else
                {
                    ShowMessage(BusinessLogicClass.fnupdateSUBMODE("R", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtSubmModeID.Text.ToString(), txtSubmModeName.Text.ToString()), string.Empty);
                    fnBindSubMode(false);
                }
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateREGULATOR("U", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtSubmModeID.Text.ToString(), txtSubmModeName.Text.ToString()), string.Empty);
                fnBindSubMode(false);
            }
        }


        [WebMethod]
        public static List<string> fnSerchSubmodeName(string prefixText, int count)// tested ok yogan.
        {
            string ssuserid = HttpContext.Current.Session["strUserId"].ToString();
            string ssrole = HttpContext.Current.Session["strRoleId"].ToString();

            DataTable dtCodeDetails = BusinessLogicClass.fnLoadSUBMODE(ssrole, ssuserid, prefixText, true, string.Empty); //Yogan Added Search by Name according to SR''

            List<string> SUBMODE_NAME = new List<string>();

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                SUBMODE_NAME.Add(dr["SUBMISSION_MODE_DESC"].ToString());
            }
            return SUBMODE_NAME;
        }
    }
}