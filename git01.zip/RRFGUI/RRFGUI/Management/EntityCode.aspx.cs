﻿using RRFGUI.Library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RRFGUI.Management
{
    public partial class EntityCode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "Entity Code";
            if (!IsPostBack)
            {
                TabContainerEntityMaintenance.ActiveTab = TabPanelListing;
                switch (Session["strRoleId"].ToString())
                {
                    case "Admin":
                        btToAdd.Visible = true;
                        DDEntityList.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
                        DDEntityList.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDEntityList.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        break;

                    case "AdminAA":
                        btToAdd.Visible = false;
                        DDEntityList.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
                        DDEntityList.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDEntityList.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        DDEntityList.Items.Add(new System.Web.UI.WebControls.ListItem("Pending", "P"));
                        break;
                }
                fnBindEntity(false);
            }
        }


        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }
        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindEntity(false);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdvwListing_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strCateId = grdvwListing.SelectedRow.Cells[1].Text;


            string strMessage = string.Empty;
            strMessage = fnEnableforEdit(strCateId);

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        private void fnBindEntity(bool isExport)
        {
            txtCEntityNo.Text = string.Empty;
            txtEntityName.Text = string.Empty;
            txtREJECT_REASON.Text = string.Empty;
            TabContainerEntityMaintenance.ActiveTab = TabPanelListing;
            string strroleid = Session["strRoleId"].ToString();
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadENTITY(strroleid, Session["strUserId"].ToString(), txtfilterEntity.Text.ToString(), isExport, DDEntityList.SelectedValue);
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();
            txtfilterEntity.Text = string.Empty;
        }

        private string fnEnableforEdit(string strCateId)
        {
            string strMessage = string.Empty;
            string strstatus = string.Empty;
            TabContainerEntityMaintenance.ActiveTab = TabPanelDetails;
            if (TabContainerEntityMaintenance.ActiveTabIndex == 1)
            {

                DataTable dtCodeDetails = BusinessLogicClass.fnGetlistENTITY(strCateId, Session["strUserId"].ToString());

                if (dtCodeDetails.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtCodeDetails.Rows)
                    {
                        txtCEntityNo.Text = dr["ENTITY_CODE"].ToString();
                        txtEntityName.Text = dr["ENTITY_CODE_NM"].ToString();
                        txtREJECT_REASON.Text = dr["REJECT_REASON"].ToString();
                        strstatus = dr["STATUS"].ToString();
                    }
                }
                else
                {
                    strMessage = "No record found";
                }

                fnEnablecntrlforEdit(strstatus);
            }

            return strMessage;
        }

        private void fnEnablecntrlforEdit(string strststus)
        {
            switch (Session["strRoleId"].ToString())
            {
                case "Admin":
                    lblEntitycode.Visible = true;
                    txtCEntityNo.Visible = true;
                    txtEntityName.Enabled = true;
                    btnUpdate.Visible = true;
                    btnAprove.Visible = false;
                    btnCreate.Visible = false;
                    break;

                case "AdminAA":

                    btnReject.Visible = true;
                    lblEntitycode.Visible = true;
                    txtCEntityNo.Visible = true;
                    txtREJECT_REASON.Enabled = true;

                    if (strststus == "A")
                    {
                        btnAprove.Visible = false;
                    }
                    else
                    {
                        btnAprove.Visible = true;
                    }
                    btnReject.Visible = true;
                    break;
            }
        }

        public bool fnvalidate()
        {
            if (string.IsNullOrEmpty(txtEntityName.Text))
            {
                ShowMessage("Please enter ENTITY_NAME", txtEntityName.ClientID.ToString());
                return false;
            }

            return true;
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtfilterEntity.Text) && !string.IsNullOrEmpty(DDEntityList.SelectedValue))
            {
                ShowMessage("Please Choose one Filter Mode", txtfilterEntity.ClientID.ToString());
            }
            else
            {
                fnBindEntity(true);
            }
        }

        protected void btToAdd_Click(object sender, EventArgs e)
        {
            TabContainerEntityMaintenance.ActiveTab = TabPanelDetails;
            txtEntityName.Text = string.Empty;
            lblEntitycode.Visible = false;
            txtCEntityNo.Visible = false;
            txtEntityName.Enabled = true;
            btnCreate.Visible = true;
            btnUpdate.Visible = false;
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateENTITY("I", "", Session["strUserId"].ToString(), "", txtEntityName.Text.ToString()), string.Empty);
                fnBindEntity(false);
            }
        }

        protected void btnAprove_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateENTITY("A", "", Session["strUserId"].ToString(), txtCEntityNo.Text.ToString(), txtEntityName.Text.ToString()), string.Empty);
                fnBindEntity(false);
            }
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                if (string.IsNullOrEmpty(txtREJECT_REASON.Text))
                {
                    ShowMessage("Please select REJECT_REASON", txtREJECT_REASON.ClientID.ToString());
                }
                else
                {
                    ShowMessage(BusinessLogicClass.fnupdateENTITY("R", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtCEntityNo.Text.ToString(), txtEntityName.Text.ToString()), string.Empty);
                    fnBindEntity(false);
                }
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateENTITY("U", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtCEntityNo.Text.ToString(), txtEntityName.Text.ToString()), string.Empty);
                fnBindEntity(false);
            }
        }

        [WebMethod]
        public static List<string> fnSerchEntityName(string prefixText, int count)// tested ok yogan.
        {
            string ssuserid = HttpContext.Current.Session["strUserId"].ToString();
            string ssrole = HttpContext.Current.Session["strRoleId"].ToString();

            DataTable dtCodeDetails = BusinessLogicClass.fnLoadENTITY(ssrole, ssuserid, prefixText, true, string.Empty); //Yogan Added Search by Name according to SR''

            List<string> Entiy_NAME = new List<string>();

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                Entiy_NAME.Add(dr["ENTITY_CODE_NM"].ToString());
            }
            return Entiy_NAME;
        }
    }
}