﻿using RRFGUI.Library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RRFGUI.Management
{
    public partial class CategoryIssueCode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "Category IssueCode";
            if (!IsPostBack)
            {
                TabContainerCategoryMaintenance.ActiveTab = TabPanelListing;
                switch (Session["strRoleId"].ToString())
                {
                    case "Admin":
                        btToAdd.Visible = true;
                        DDCateList.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
                        DDCateList.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDCateList.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        break;

                    case "AdminAA":
                        btToAdd.Visible = false;
                        DDCateList.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
                        DDCateList.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDCateList.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        DDCateList.Items.Add(new System.Web.UI.WebControls.ListItem("Pending", "P"));
                        break;
                }
                fnBindCategory(false);
            }
        }


        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }


        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindCategory(false);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdvwListing_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strCateId = grdvwListing.SelectedRow.Cells[1].Text;


            string strMessage = string.Empty;
            strMessage = fnEnableforEdit(strCateId);

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        private void fnBindCategory(bool isExport)
        {
            txtCateNo.Text = string.Empty;
            txtCateName.Text = string.Empty;
            txtREJECT_REASON.Text = string.Empty;
            TabContainerCategoryMaintenance.ActiveTab = TabPanelListing;
            string strroleid = Session["strRoleId"].ToString();
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadCATE(strroleid, Session["strUserId"].ToString(), txtfilterCategory.Text.ToString(), isExport, DDCateList.SelectedValue);
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();
            txtfilterCategory.Text = string.Empty;
        }

        private string fnEnableforEdit(string strCateId)
        {
            string strMessage = string.Empty;
            string strstatus = string.Empty;
            TabContainerCategoryMaintenance.ActiveTab = TabPanelDetails;
            if (TabContainerCategoryMaintenance.ActiveTabIndex == 1)
            {

                DataTable dtCodeDetails = BusinessLogicClass.fnGetlistCATE(strCateId, Session["strUserId"].ToString());

                if (dtCodeDetails.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtCodeDetails.Rows)
                    {
                        txtCateNo.Text = dr["CATEGORY_ISSUE_ID"].ToString();
                        txtCateName.Text = dr["CATEGORY_ISSUE_DESC"].ToString();
                        txtREJECT_REASON.Text = dr["REJECT_REASON"].ToString();
                        strstatus = dr["STATUS"].ToString();
                     }

                }
                else
                {
                    strMessage = "No record found";
                }

                fnEnablecntrlforEdit(strstatus);
            }

            return strMessage;
        }

        private void fnEnablecntrlforEdit(string strststus)
        {
            switch (Session["strRoleId"].ToString())
            {
                case "Admin":
                    lblCatecode.Visible = true;
                    txtCateNo.Visible = true;
                    txtCateName.Enabled = true;
                    btnUpdate.Visible = true;
                    btnAprove.Visible = false;
                    btnCreate.Visible = false;
                    break;

                case "AdminAA":

                    btnReject.Visible = true;
                    lblCatecode.Visible = true;
                    txtCateNo.Visible = true;
                    txtREJECT_REASON.Enabled = true;

                    if (strststus == "A")
                    {
                        btnAprove.Visible = false;
                    }
                    else
                    {
                        btnAprove.Visible = true;
                    }
                    btnReject.Visible = true;
                    break;
            }
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtfilterCategory.Text) && !string.IsNullOrEmpty(DDCateList.SelectedValue))
            {
                ShowMessage("Please Choose one Filter Mode", txtfilterCategory.ClientID.ToString());
            }
            else
            {
                fnBindCategory(true);
            }
        }

        protected void btToAdd_Click(object sender, EventArgs e)
        {
            TabContainerCategoryMaintenance.ActiveTab = TabPanelDetails;
            txtCateName.Text = string.Empty;
            lblCatecode.Visible = false;
            txtCateNo.Visible = false;
            txtCateName.Enabled = true;
            btnCreate.Visible = true;
            btnUpdate.Visible = false;
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateCATE("I", "", Session["strUserId"].ToString(), "", txtCateName.Text.ToString()), string.Empty);
                fnBindCategory(false);
            }
        }

        protected void btnAprove_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateCATE("A", "", Session["strUserId"].ToString(), txtCateNo.Text.ToString(), txtCateName.Text.ToString()), string.Empty);
                fnBindCategory(false);
            }
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                if (string.IsNullOrEmpty(txtREJECT_REASON.Text))
                {
                    ShowMessage("Please select REJECT_REASON", txtREJECT_REASON.ClientID.ToString());
                }
                else
                {
                    ShowMessage(BusinessLogicClass.fnupdateCATE("R", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtCateNo.Text.ToString(), txtCateName.Text.ToString()), string.Empty);
                    fnBindCategory(false);
                }
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (fnvalidate() == true)
            {
                ShowMessage(BusinessLogicClass.fnupdateCATE("U", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtCateNo.Text.ToString(), txtCateName.Text.ToString()), string.Empty);
                fnBindCategory(false);
            }
        }

        public bool fnvalidate()
        {
            if (string.IsNullOrEmpty(txtCateName.Text))
            {
                ShowMessage("Please enter DEPT_NAME", txtCateName.ClientID.ToString());
                return false;
            }

           return true;
        }

        [WebMethod]
        public static List<string> fnSerchCategName(string prefixText, int count)// tested ok yogan.
        {
            string ssuserid = HttpContext.Current.Session["strUserId"].ToString();
            string ssrole = HttpContext.Current.Session["strRoleId"].ToString();

            DataTable dtCodeDetails = BusinessLogicClass.fnLoadCATE(ssrole, ssuserid, prefixText, true, string.Empty); //Yogan Added Search by Name according to SR''

            List<string> CODE_NM_NAME = new List<string>();

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                CODE_NM_NAME.Add(dr["CATEGORY_ISSUE_DESC"].ToString());
            }
            return CODE_NM_NAME;
        }

    }
}