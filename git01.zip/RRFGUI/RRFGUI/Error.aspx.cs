﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RRFGUI.Library;

namespace RRFGUI
{
    public partial class Error : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void lnkbtnBacktohome_Click(object sender, EventArgs e)
        {
            fnLogOut();
        }

        protected void fnLogOut()
        {
            if (Session["MenuGroup"] != null)
            {
                string strUserName = Session["strUserId"].ToString();
                string strDomainName = Session["strDomainName"].ToString();
                string strClientIpAddress = Session["ClientIPAddress"].ToString();

                BusinessLogicClass.fnUpdateUserStatusforLoginAndLogOut("N", strUserName, strDomainName, strClientIpAddress);
                BusinessLogicClass.fnLogMaintenance(Session.SessionID, "LO", strUserName, strDomainName, strClientIpAddress, "OK", "Log out Successful");

                Session["strUserId"] = null;
                Session["strUnitId"] = null;
                Session["strRoleId"] = null;
                //Session["strUserRole"] = null;
                Session["dtAccessControll"] = null;
                Session["strDomainName"] = null;
                Session["ClientIPAddress"] = null;
                Session["MenuGroup"] = null;
                Session["PageCodeLinks"] = null;
                Session.Clear();
                Session.Abandon();

                Response.Redirect("~/Login.aspx"); ;
            }
        }
    }
}