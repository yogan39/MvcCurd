﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using AjaxControlToolkit;
using RRFGUI.Library;

namespace RRFGUI
{
    public partial class Site : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //megatshamsul - 20161116 - to take out IP address as per user request during mtg on 16/11/2016
                //lblCurrentUser.Text = "Current User : " + Session["strDomainName"].ToString() + "\\" + Session["strUserId"].ToString() + " - " + Session["strUserName"] + " (" + Session["ClientIPAddress"].ToString() + ")";
                lblCurrentUser.Text = "Current User : " + Session["strDomainName"].ToString() + "\\" + Session["strUserId"].ToString() + " - " + Session["strUserName"];
                lblCurrentUser.ForeColor = System.Drawing.ColorTranslator.FromHtml("#EC1C24");
                lblCurrentUser.Font.Bold = true;
            }
            else
            {
                string strCntrlName = this.Page.Request.Params.Get("__EVENTTARGET");

                if (!string.IsNullOrEmpty(strCntrlName))
                {
                    if (strCntrlName == hiddenfldforClose.ClientID)
                    {
                        fnLogOutUpdates();
                    }
                }
            }

            fnLoadAccordianMenuControl();

            if (Request.QueryString["PaneID"] != null)
            {
                string strPaneId = Request.QueryString["PaneID"];
                int selPaneId = Convert.ToInt32(strPaneId) - 1;

                ((Accordion)FindControl("MenuAccordian")).SelectedIndex = selPaneId;
            }
        }

        protected void fnLoadAccordianMenuControl()
        {
            try
            {
                string strUserID = Session["strUserId"].ToString();

                PlaceHolderforMenuControl.Controls.Clear();

                Accordion MenuAccordian = new Accordion();
                MenuAccordian.ID = "MenuAccordian";
                MenuAccordian.CssClass = "accordian";
                MenuAccordian.HeaderCssClass = "accordionHeader";
                MenuAccordian.HeaderSelectedCssClass = "accordionHeaderSelected";
                MenuAccordian.ContentCssClass = "accordionContent";

                AccordionPane DynamicPane;
                Label DynamicLabel;
                Button DynamicButton;

                DataSet objDataSet = (DataSet)Session["MenuGroup"];
                DataTable dtMenuGroup = objDataSet.Tables[0];
                DataTable dtMenuPages = objDataSet.Tables[1];
                DataTable dtAccessControll = (DataTable)Session["dtAccessControll"];

                if (dtMenuGroup.Rows.Count > 1)
                {
                    foreach (DataRow dr in dtMenuGroup.Rows)
                    {
                        //Pane is Created
                        DynamicPane = new AccordionPane();
                        DynamicPane.ID = dr["GrpId"].ToString();
                        DynamicLabel = new Label();
                        DynamicLabel.ID = "lbl" + dr["GrpId"].ToString();
                        DynamicLabel.Text = dr["MenuGroup"].ToString();
                        //Pane Header Controll for Name of the Menu is added
                        DynamicPane.HeaderContainer.Controls.Add(DynamicLabel);

                        foreach (DataRow drPages in dtMenuPages.Rows)
                        {
                            //Pane Container
                            if (dr["GrpId"].ToString() == drPages["GrpId"].ToString())
                            {
                                DynamicButton = new Button();
                                DynamicButton.ID = "btn" + drPages["PageDesc"].ToString().Trim();
                                DynamicButton.Text = drPages["PageDesc"].ToString().Trim();
                                //DynamicButton.Width = 200;

                                DynamicButton.CssClass = "BtnAutoSize";

                                foreach (DataRow drAccessControl in dtAccessControll.Rows)
                                {
                                    if (drPages["PageCode"].ToString() == drAccessControl["PageCode"].ToString())
                                    {
                                        string pgUrl = drPages["Url"].ToString() + "?UserID=" + strUserID;
                                        pgUrl += "&PaneID=" + dr["SeqNo"].ToString();

                                        DynamicButton.PostBackUrl = "~/" + pgUrl;//drPages["Url"].ToString();
                                        DynamicButton.Enabled = true;
                                        break;
                                    }
                                    else
                                    {
                                        DynamicButton.Enabled = false;
                                    }
                                }

                                //megat - to disable button link if all db options is "N"
                                if (dtAccessControll.Rows.Count == 0)
                                    DynamicButton.Enabled = false;

                                //If pane contains atleast one Controll it will add break
                                if (DynamicPane.ContentContainer.Controls.Count > 0)
                                {
                                    DynamicPane.ContentContainer.Controls.Add(new LiteralControl("<br />"));
                                }

                                DynamicPane.ContentContainer.Controls.Add(DynamicButton);
                            }
                        }

                        MenuAccordian.Panes.Add(DynamicPane);
                    }
                }

                PlaceHolderforMenuControl.Controls.Add(MenuAccordian);
            }
            catch (System.Exception ex)
            {
                if (Session["strUserId"] == null)
                    BusinessLogicClass.fnLogErrorInFile(12, "SiteMaster.fnLoadAccordianMenuControl.Exception", ex.Message, "NULL");
                else
                    BusinessLogicClass.fnLogErrorInFile(12, "SiteMaster.fnLoadAccordianMenuControl.Exception", ex.Message, Session["strUserId"].ToString());

                Response.Redirect("~/Login.aspx?IsSessionExpire=true");
            }
        }

        protected void LinkBtnLogOut_Click(object sender, EventArgs e)
        {
            //pending:
            /*
            if (!string.IsNullOrEmpty((string)Session["UnsavedChanges"]))
            {
                if ((string)Session["UnsavedChanges"] == "true")
                {
                    if (string.IsNullOrEmpty(hiddenfld.Value.ToString()))
                    {
                        Page.RegisterStartupScript("myScript", "<script language=JavaScript>winClose();</script>");
                    }
                }
                else
                {
                    fnLogOutUpdates();
                    Response.Write("<script type='text/javascript'> " + "window.opener = 'Self';" + "window.open('','_parent','');" + "window.close(); " + "</script>");
                }
            }
            else
            {
            */
            fnLogOutUpdates();

            //Response.Write("<script type='text/javascript'> " + "window.opener = 'Self';" + "window.open('','_parent','');" + "window.close(); " + "</script>");
            Response.Redirect("~/Login.aspx"); ;
            //}
        }

        public void fnLogOutUpdates()
        {
            if (Session["MenuGroup"] != null)
            {
                string strUserName = Session["strUserId"].ToString();
                string strDomainName = Session["strDomainName"].ToString();
                string strClientIpAddress = Session["ClientIPAddress"].ToString();

                BusinessLogicClass.fnUpdateUserStatusforLoginAndLogOut("N", strUserName, strDomainName, strClientIpAddress);
                BusinessLogicClass.fnLogMaintenance(Session.SessionID, "LO", strUserName, strDomainName, strClientIpAddress, "OK", "Log out Successful");

                Session["strUserId"] = null;
                Session["strUnitId"] = null;
                Session["strRoleId"] = null;
                //Session["strUserRole"] = null;
                Session["dtAccessControll"] = null;
                Session["strDomainName"] = null;
                Session["ClientIPAddress"] = null;
                Session["MenuGroup"] = null;
                //Session["IsApprover"] = null;

                Session.Clear();
                Session.Abandon();

                Response.Write("<script type='text/javascript'> " + "window.opener = 'Self';" + "window.open('','_parent','');" + "window.close(); " + "</script>");
            }
        }
    }
}