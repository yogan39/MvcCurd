﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using RRFGUI.Library;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Threading;
using System.Text;
using System.Web.Services;

namespace RRFGUI.Maintenance
{
    public partial class ESubmission : System.Web.UI.Page
    {
        string strSUBMISSION_ID = string.Empty;
        string strSTATUS_ID = string.Empty;
        string strROW_NUM = string.Empty;

        //megatshamsul - 20170317 - SR1363674 - add const fields for checking
        string SREF_Yes_MP = "Yes(Monetary Penalty)";
        string SREF_Yes_NMP = "Yes(Non-Monetary Penalty)";

        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "E-SUBMISSION MAINTENANCE";
            txtHdnRoleId.Text = Session["strRoleId"].ToString();

            if (!IsPostBack)
            {
                TabContainerESubmission.ActiveTab = TabPanelListing;

                switch (Session["strRoleId"].ToString())
                {
                    case "Preparer":
                        chkbxFilterStatusDue.Checked = true;
                        chkbxFilterStatusPastDue.Checked = true;
                        break;
                    case "Approver":
                    case "FGTAppvr":
                        chkbxFilterStatusPendingApproval.Checked = true;
                        break;
                }

                fnLoadRegulatorCode();
                fnLoadSREFCode();
                fnLoadFrequencyCode();
                fnLoadCompliance();
                fnLoadRRFJustification();
                fnLoadCategoryIssueCode();
                fnLoadStatusCode();
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();
            }
        }

        #region PreLoading
                
        private void fnLoadRegulatorCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadRegulatorCode(Session["strUserId"].ToString());

            ddlFilterREGULATOR_ID.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            
            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlFilterREGULATOR_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["REGULATOR_DESC"].ToString(), dr["REGULATOR_ID"].ToString()));
            }
        }

        private void fnLoadSREFCode()
        {
            ddlFilterSREF.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            ddlFilterSREF.Items.Add(new System.Web.UI.WebControls.ListItem("Yes(Monetary Penalty)", "1"));
            ddlFilterSREF.Items.Add(new System.Web.UI.WebControls.ListItem("Yes(Non-Monetary Penalty)", "2"));
            ddlFilterSREF.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));
        }

        private void fnLoadFrequencyCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadFrequencyCode(Session["strUserId"].ToString());

            ddlFilterFREQUENCY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlFilterFREQUENCY_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["FREQUENCY_DESC"].ToString(), dr["FREQUENCY_ID"].ToString()));
            }
        }

        private void fnLoadCompliance()
        {
            ddlCOMPLIANCE.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlCOMPLIANCE.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlCOMPLIANCE.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));
        }

        private void fnLoadRRFJustification()
        {
            ddlRRF_JUSTIFICATION.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlRRF_JUSTIFICATION.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlRRF_JUSTIFICATION.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_JUSTIFICATION_1.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlRESUBMISSION_JUSTIFICATION_1.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlRESUBMISSION_JUSTIFICATION_1.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_JUSTIFICATION_2.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlRESUBMISSION_JUSTIFICATION_2.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlRESUBMISSION_JUSTIFICATION_2.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_JUSTIFICATION_3.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlRESUBMISSION_JUSTIFICATION_3.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlRESUBMISSION_JUSTIFICATION_3.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_JUSTIFICATION_4.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlRESUBMISSION_JUSTIFICATION_4.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlRESUBMISSION_JUSTIFICATION_4.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_JUSTIFICATION_5.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlRESUBMISSION_JUSTIFICATION_5.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlRESUBMISSION_JUSTIFICATION_5.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));
        }

        private void fnLoadCategoryIssueCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadCategoryIssueCode(Session["strUserId"].ToString());

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //ddlCATEGORY_ISSUE_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            //
            //foreach (DataRow dr in dtCodeDetails.Rows)
            //{
            //    ddlCATEGORY_ISSUE_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["CATEGORY_ISSUE_DESC"].ToString(), dr["CATEGORY_ISSUE_ID"].ToString()));
            //}

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_CATEGORY_ISSUE_1.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlRESUBMISSION_CATEGORY_ISSUE_1.Items.Add(new System.Web.UI.WebControls.ListItem(dr["CATEGORY_ISSUE_DESC"].ToString(), dr["CATEGORY_ISSUE_ID"].ToString()));
            }

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_CATEGORY_ISSUE_2.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlRESUBMISSION_CATEGORY_ISSUE_2.Items.Add(new System.Web.UI.WebControls.ListItem(dr["CATEGORY_ISSUE_DESC"].ToString(), dr["CATEGORY_ISSUE_ID"].ToString()));
            }

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_CATEGORY_ISSUE_3.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlRESUBMISSION_CATEGORY_ISSUE_3.Items.Add(new System.Web.UI.WebControls.ListItem(dr["CATEGORY_ISSUE_DESC"].ToString(), dr["CATEGORY_ISSUE_ID"].ToString()));
            }

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_CATEGORY_ISSUE_4.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlRESUBMISSION_CATEGORY_ISSUE_4.Items.Add(new System.Web.UI.WebControls.ListItem(dr["CATEGORY_ISSUE_DESC"].ToString(), dr["CATEGORY_ISSUE_ID"].ToString()));
            }

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            ddlRESUBMISSION_CATEGORY_ISSUE_5.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlRESUBMISSION_CATEGORY_ISSUE_5.Items.Add(new System.Web.UI.WebControls.ListItem(dr["CATEGORY_ISSUE_DESC"].ToString(), dr["CATEGORY_ISSUE_ID"].ToString()));
            }
        }

        private void fnLoadStatusCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadApprovalStatusCode(Session["strUserId"].ToString());

            ddlSTATUS_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlSTATUS_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["STATUS_DESC"].ToString(), dr["STATUS_ID"].ToString()));
            }
        }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        #endregion

        #region Listing

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            strSUBMISSION_ID = grdvwListing.SelectedRow.Cells[1].Text;
            strSTATUS_ID = grdvwListing.SelectedRow.Cells[11].Text;
            strROW_NUM = grdvwListing.SelectedRow.Cells[12].Text;

            txtHdnFromListing.Text = "L";

            string strMessage = string.Empty;
            strMessage = fnShowSelectedData();

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindListing(false);
        }

        protected void grdvwListing_OnRowDataBound(Object Sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header || e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[10].Visible = false;    //hide STATUS_ID
                e.Row.Cells[11].Visible = false;    //hide ROW_NUM
            }
        }

        protected void btnListRefresh_OnClick(object sender, EventArgs e)
        {
            fnBindListing(false);
        }

        private void fnBindListing(bool ifExport)
        {
            bool ifOK = false;

            if (string.IsNullOrEmpty(txtFilterDateFrom.Text) && string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ifOK = true;
            }
            else if (string.IsNullOrEmpty(txtFilterDateFrom.Text) && !string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ShowMessage("Please select Date From", txtFilterDateFrom.ClientID.ToString());
            }
            else if (!string.IsNullOrEmpty(txtFilterDateFrom.Text) && string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ShowMessage("Please select Date To", txtFilterDateTo.ClientID.ToString());
            }
            else if (!string.IsNullOrEmpty(txtFilterDateFrom.Text) && !string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                if (BusinessLogicClass.fnValidateDatesRange(txtFilterDateFrom.Text, txtFilterDateTo.Text))
                    ifOK = true;
                else
                    ShowMessage("Please select correct Date range", txtFilterDateFrom.ClientID.ToString());
            }

            if (ifOK)
            {
                if (!string.IsNullOrEmpty(txtFilterRPT_ID.Text))
                {
                    if (txtFilterRPT_ID.Text.Length < 9)
                    {
                        txtFilterRPT_ID.Text = txtFilterRPT_ID.Text.PadLeft(9, '0');
                    }
                }

                DataTable dtCodeDetails = BusinessLogicClass.fnListESubmissions(txtFilterRPT_ID.Text, txtFilterRPT_NAME.Text, ddlFilterREGULATOR_ID.SelectedValue, ddlFilterSREF.SelectedValue, ddlFilterFREQUENCY_ID.SelectedValue, chkbxFilterStatusAll.Checked, chkbxFilterStatusDraft.Checked, chkbxFilterStatusNew.Checked, chkbxFilterStatusApproved.Checked, chkbxFilterStatusRejected.Checked, chkbxFilterStatusPendingApproval.Checked, chkbxFilterStatusDue.Checked, chkbxFilterStatusPastDue.Checked, txtFilterDateFrom.Text, txtFilterDateTo.Text, Session["strUserId"].ToString(), Session["strUnitId"].ToString(), Session["strRoleId"].ToString(), ifExport, false);
                grdvwListing.DataSource = dtCodeDetails;
                grdvwListing.DataBind();

                if (!ifExport)
                    lblTotalListing.Text = "Total: " + dtCodeDetails.Rows.Count.ToString();
            }
        }

        #endregion

        #region Listing Reject Bucket

        protected void grdvwListingRejectBucket_SelectedIndexChanged(object sender, EventArgs e)
        {
            strSUBMISSION_ID = grdvwListingRejectBucket.SelectedRow.Cells[1].Text;
            strSTATUS_ID = grdvwListingRejectBucket.SelectedRow.Cells[11].Text;
            strROW_NUM = grdvwListingRejectBucket.SelectedRow.Cells[12].Text;

            txtHdnFromListing.Text = "R";

            string strMessage = string.Empty;
            strMessage = fnShowSelectedData();

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        protected void grdvwListingRejectBucket_RowCreated(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdvwListingRejectBucket_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListingRejectBucket.PageIndex = e.NewPageIndex;
            fnBindListingReject();
        }

        protected void grdvwListingRejectBucket_OnRowDataBound(Object Sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header || e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[10].Visible = false;    //hide STATUS_ID
                e.Row.Cells[11].Visible = false;    //hide ROW_NUM            
            }
        }

        protected void btnListRejectBucketRefresh_OnClick(object sender, EventArgs e)
        {
            fnBindListingReject();
        }

        private void fnBindListingReject()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListESubmissions(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, false, false, false, false, true, false, false, false, string.Empty, string.Empty, Session["strUserId"].ToString(), Session["strUnitId"].ToString(), Session["strRoleId"].ToString(), false, true);
            grdvwListingRejectBucket.DataSource = dtCodeDetails;
            grdvwListingRejectBucket.DataBind();

            lblTotalListingRejectBucket.Text = "Total: " + dtCodeDetails.Rows.Count.ToString();
        }

        #endregion

        #region Details

        private string fnShowSelectedData()
        {
            TabContainerESubmission.ActiveTab = TabPanelDetails;

            string strMessage = string.Empty;
            System.Web.UI.WebControls.ListItem oListItem;

            DataTable dtCodeDetails = BusinessLogicClass.fnGetESubmissionDetails(strSUBMISSION_ID, strSTATUS_ID, strROW_NUM, Session["strUnitId"].ToString(), Session["strUserId"].ToString(), Session["strRoleId"].ToString());

            if (dtCodeDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtCodeDetails.Rows)
                {
                    txtHdnROW_NUM.Text = strROW_NUM;

                    txtSUBMISSION_ID.Text = strSUBMISSION_ID;
                    txtRPT_ID.Text = dr["RPT_ID"].ToString();
                    txtRPT_NAME.Text = dr["RPT_NAME"].ToString();
                    txtPOSITION_DATE.Text = dr["POSITION_DATE"].ToString();
                    txtTARGET_SUBMISSION_DATE.Text = dr["TARGET_SUBMISSION_DATE"].ToString();
                    
                    txtSREF.Text = dr["SREF"].ToString();
                    txtUNIT_ID.Text = dr["UNIT_ID"].ToString();
                    txtHdnUNIT_ID.Text = dr["ACTUAL_UNIT_ID"].ToString();
                    txtENTITY_ID.Text = dr["ENTITY_ID"].ToString();
                    txtFREQUENCY_ID.Text = dr["FREQUENCY_ID"].ToString();
                    txtSUBMISSION_MODE_ID.Text = dr["SUBMISSION_MODE_ID"].ToString();

                    txtAPPROVED_EXTENDED_DATE.Text = dr["APPROVED_EXTENDED_DATE"].ToString();
                    txtHdnEXTENDED_DATE.Text = txtAPPROVED_EXTENDED_DATE.Text;

                    //megatshamsul - 20170317 - SR1363674 - obsolete fields
                    //txtRESUBMISSION_NO.Text = dr["RESUBMISSION_NO"].ToString();
                    //txtHdnRESUBMISSION_NO.Text = txtRESUBMISSION_NO.Text;
                    //txtHdnRESUBMISSION_NO_updt.Text = txtRESUBMISSION_NO.Text;

                    lbEXTENDED_ATTACHMENT_NAME.Text = dr["EXTENDED_ATTACHMENT_NAME"].ToString();

                    if (lbEXTENDED_ATTACHMENT_NAME.Text.Length > 0)
                    {
                        //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT + resubmission attachments
                        //lbEXTENDED_ATTACHMENT_NAME.OnClientClick = "return fnShowAttachment('" + strROW_NUM + "');";
                        lbEXTENDED_ATTACHMENT_NAME.OnClientClick = "return fnShowAttachment('" + strROW_NUM + "','EXTENDED','');";
                    }

                    //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
                    //txtHdnRMV_ATTACHMENT.Text = "0";
                    txtHdnRMV_EXTENDED_ATTACHMENT.Text = "0";

                    //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
                    lbJUSTIFICATION_ATTACHMENT_NAME.Text = dr["JUSTIFICATION_ATTACHMENT_NAME"].ToString();

                    //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
                    if (lbJUSTIFICATION_ATTACHMENT_NAME.Text.Length > 0)
                        lbJUSTIFICATION_ATTACHMENT_NAME.OnClientClick = "return fnShowAttachment('" + strROW_NUM + "','JUSTIFICATION','');";

                    //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
                    txtHdnRMV_JUSTIFICATION_ATTACHMENT.Text = "0";

                    txtEXTENDED_REASON.Text = dr["EXTENDED_REASON"].ToString();

                    txtACTUAL_SUBMISSION_DATE.Text = dr["ACTUAL_SUBMISSION_DATE"].ToString();

                    oListItem = ddlCOMPLIANCE.Items.FindByValue(dr["COMPLIANCE"].ToString());
                    if (oListItem != null)
                        ddlCOMPLIANCE.SelectedValue = oListItem.Value;

                    txtHdnCOMPLIANCE.Text = dr["COMPLIANCE"].ToString();

                    //megatshamsul - 20170317 - SR1363674 - obsolete fields
                    //txtCOMPLIANCE_REMARK.Text = dr["COMPLIANCE_REMARK"].ToString();

                    oListItem = ddlRRF_JUSTIFICATION.Items.FindByValue(dr["RRF_JUSTIFICATION"].ToString());
                    if (oListItem != null)
                        ddlRRF_JUSTIFICATION.SelectedValue = oListItem.Value;

                    txtHdnRRF_JUSTIFICATION.Text = dr["RRF_JUSTIFICATION"].ToString();

                    //megatshamsul - 20170317 - SR1363674 - obsolete fields
                    //oListItem = ddlCATEGORY_ISSUE_ID.Items.FindByValue(dr["CATEGORY_ISSUE_ID"].ToString());
                    //if (oListItem != null)
                    //    ddlCATEGORY_ISSUE_ID.SelectedValue = oListItem.Value;

                    //megatshamsul - 20170317 - SR1363674 - obsolete fields
                    //txtDESCRIPTION_ISSUE.Text = dr["DESCRIPTION_ISSUE"].ToString();
                    //txtIMPACT_ISSUE.Text = dr["IMPACT_ISSUE"].ToString();
                    //txtCAUSAL.Text = dr["CAUSAL"].ToString();
                    //txtACTION_PLAN.Text = dr["ACTION_PLAN"].ToString();
                    //txtSTATUS_UPDATE.Text = dr["STATUS_UPDATE"].ToString();

                    //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
                    DataTable dtResubmissionDetails = BusinessLogicClass.fnGetESubmissionResubmissionDetails(strROW_NUM, Session["strUserId"].ToString());

                    //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
                    if (dtResubmissionDetails.Rows.Count > 0)
                    {
                        DropDownList DropDownList1 = null;
                        TextBox TextBox1 = null;
                        FileUpload FileUpload1 = null;
                        LinkButton LinkButton1 = null;
                        string ObjectId = string.Empty;
                        int y = 1;

                        foreach (DataRow drResubmission in dtResubmissionDetails.Rows)
                        {
                            ObjectId = "txtRESUBMISSION_DATE_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (TextBox1 != null)
                                TextBox1.Text = drResubmission["RESUBMISSION_DATE"].ToString();

                            ObjectId = "ddlRESUBMISSION_JUSTIFICATION_" + y;
                            DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                            if (DropDownList1 != null)
                            {
                                oListItem = DropDownList1.Items.FindByValue(drResubmission["RRF_JUSTIFICATION"].ToString());
                                if (oListItem != null)
                                    DropDownList1.SelectedValue = oListItem.Value;
                            }

                            ObjectId = "ddlRESUBMISSION_CATEGORY_ISSUE_" + y;
                            DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                            if (DropDownList1 != null)
                            {
                                oListItem = DropDownList1.Items.FindByValue(drResubmission["CATEGORY_ISSUE_ID"].ToString());
                                if (oListItem != null)
                                    DropDownList1.SelectedValue = oListItem.Value;
                            }

                            ObjectId = "txtRESUBMISSION_DESCRIPTION_ISSUE_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (TextBox1 != null)
                                TextBox1.Text = drResubmission["DESCRIPTION_ISSUE"].ToString();

                            ObjectId = "txtRESUBMISSION_IMPACT_ISSUE_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (TextBox1 != null)
                                TextBox1.Text = drResubmission["IMPACT_ISSUE"].ToString();

                            ObjectId = "txtRESUBMISSION_CAUSAL_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (TextBox1 != null)
                                TextBox1.Text = drResubmission["CAUSAL"].ToString();

                            ObjectId = "txtRESUBMISSION_ACTION_PLAN_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (TextBox1 != null)
                                TextBox1.Text = drResubmission["ACTION_PLAN"].ToString();

                            ObjectId = "txtRESUBMISSION_STATUS_UPDATE_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (TextBox1 != null)
                                TextBox1.Text = drResubmission["STATUS_UPDATE"].ToString();

                            ObjectId = "fuRESUBMISSION_ATTACHMENT_" + y;
                            FileUpload1 = FindControlRecursive(Page, ObjectId) as FileUpload;

                            ObjectId = "lbRESUBMISSION_ATTACHMENT_NAME_" + y;
                            LinkButton1 = FindControlRecursive(Page, ObjectId) as LinkButton;

                            ObjectId = "txtHdnRMV_RESUBMISSION_ATTACHMENT_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (FileUpload1 != null && LinkButton1 != null && TextBox1 != null)
                            {
                                LinkButton1.Text = drResubmission["RESUBMISSION_ATTACHMENT_NAME"].ToString();

                                if (LinkButton1.Text.Length > 0)
                                    LinkButton1.OnClientClick = "return fnShowAttachment('" + strROW_NUM + "','RESUBMISSION','" + y.ToString() + "');";

                                TextBox1.Text = "0";
                            }

                            y++;
                        }
                    }

                    //megatshamsul - 20170322 - SR1363674 - set status 'AP2' as APPROVED if compliance, else status quo
                    //oListItem = ddlSTATUS_ID.Items.FindByValue(strSTATUS_ID);
                    if (strSTATUS_ID == "AP2" && ddlCOMPLIANCE.SelectedValue=="Y")
                        oListItem = ddlSTATUS_ID.Items.FindByValue("AP1");
                    else
                        oListItem = ddlSTATUS_ID.Items.FindByValue(strSTATUS_ID);

                    if (oListItem != null)
                        ddlSTATUS_ID.SelectedValue = oListItem.Value;

                    txtCREATE_DATE.Text = dr["CREATE_DATE"].ToString();
                    txtPREPARER_ID.Text = dr["PREPARER_ID"].ToString();
                    txtPREPARER_DATE.Text = dr["PREPARER_DATE"].ToString();
                    txtAPPROVER_ID.Text = dr["APPROVER_ID"].ToString();
                    txtAPPROVER_DATE.Text = dr["APPROVER_DATE"].ToString();
                    txtAPPROVER_FGT_ID.Text = dr["APPROVER_FGT_ID"].ToString();
                    txtAPPROVER_FGT_DATE.Text = dr["APPROVER_FGT_DATE"].ToString();

                    txtREJECT_REASON.Text = dr["REJECT_REASON"].ToString();
                }

                txtREJECT_REASON.Enabled = false;
                btnApproval.Enabled = false;
                btnApproval.Visible = false;
                lblApprovalButtonSpace.Visible = false;
                btnReject.Enabled = false;
                btnReject.Visible = false;

                switch (Session["strRoleId"].ToString())
                {
                    case "Approver":

                        switch (ddlSTATUS_ID.SelectedValue)
                        {
                            case "N":
                            case "U":
                            case "XR":
                                txtREJECT_REASON.Enabled = true;
                                btnApproval.Enabled = true;
                                btnApproval.Visible = true;
                                lblApprovalButtonSpace.Visible = true;
                                btnReject.Enabled = true;
                                btnReject.Visible = true;
                                break;
                        }

                        break;

                    case "FGTAppvr":

                        switch (ddlSTATUS_ID.SelectedValue)
                        {
                            case "AP1":
                            case "APX1":
                                txtREJECT_REASON.Enabled = true;
                                btnApproval.Enabled = true;
                                btnApproval.Visible = true;
                                lblApprovalButtonSpace.Visible = true;
                                btnReject.Enabled = true;
                                btnReject.Visible = true;
                                break;
                            case "AP2": //only FGT can reject an approved rec
                                txtREJECT_REASON.Enabled = true;
                                btnApproval.Enabled = false;
                                btnApproval.Visible = false;
                                lblApprovalButtonSpace.Visible = false;
                                btnReject.Enabled = true;
                                btnReject.Visible = true;
                                break;
                        }

                        break;

                    case "Preparer":

                        //disable updates button if already submitted
                        switch (ddlSTATUS_ID.SelectedValue)
                        {
                            case "D1":
                            case "D2":
                            case "D3":
                            case "RJ1":
                            case "RJ2":
                            case "RJX1":
                            case "RJX2":
                                EnableFieldsForAddEdit("U", true);
                                break;
                            default:
                                EnableFieldsForAddEdit("U", false);
                                break;
                        }

                        break;

                }

            }
            else
                strMessage = "No record found";

            return strMessage;
        }

        protected void btnUpdateESubmission_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("U"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateESubmission("U", ddlSTATUS_ID.SelectedValue, "D2", ref ifSuccess), string.Empty);
                string sRptName = txtRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    DataTable dtEmailCC = new DataTable();
                    string sEmailSubject = "Updated E-Submission Created In Your Queue";
                    string sEmailBody = "E-Submission report name " + sRptName + " has been saved in your queue by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ").";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                if (txtHdnFromListing.Text == "L")
                    TabContainerESubmission.ActiveTab = TabPanelListing;
                else if (txtHdnFromListing.Text == "R")
                    TabContainerESubmission.ActiveTab = TabPanelListingReject;
            }
        }

        protected void btnUpdateSubmitESubmission_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("U"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateESubmission("U", ddlSTATUS_ID.SelectedValue, "U", ref ifSuccess), string.Empty);
                string sRptName = txtRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = "Updated E-Submission Has Been Submitted For Approval";
                    string sEmailBody = "E-Submission report name " + sRptName + " has been submitted by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and is in Approvers queue. Please act accordingly.";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                if (txtHdnFromListing.Text == "L")
                    TabContainerESubmission.ActiveTab = TabPanelListing;
                else if (txtHdnFromListing.Text == "R")
                    TabContainerESubmission.ActiveTab = TabPanelListingReject;
            }
        }

        protected void btnDeleteESubmission_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("D"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateESubmission("D", ddlSTATUS_ID.SelectedValue, "D3", ref ifSuccess), string.Empty);
                string sRptName = txtRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    DataTable dtEmailCC = new DataTable();
                    string sEmailSubject = "Discontinue E-Submission Created In Your Queue";
                    string sEmailBody = "E-Submission report name " + sRptName + " has been saved in your queue by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ").";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                if (txtHdnFromListing.Text == "L")
                    TabContainerESubmission.ActiveTab = TabPanelListing;
                else if (txtHdnFromListing.Text == "R")
                    TabContainerESubmission.ActiveTab = TabPanelListingReject;
            }
        }

        protected void btnDeleteSubmitESubmission_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("D"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateESubmission("D", ddlSTATUS_ID.SelectedValue, "XR", ref ifSuccess), string.Empty);
                string sRptName = txtRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = "Discontinue E-Submission Has Been Submitted For Approval";
                    string sEmailBody = "E-Template report name " + sRptName + " has been submitted by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and is in Approvers queue. Please act accordingly.";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                if (txtHdnFromListing.Text == "L")
                    TabContainerESubmission.ActiveTab = TabPanelListing;
                else if (txtHdnFromListing.Text == "R")
                    TabContainerESubmission.ActiveTab = TabPanelListingReject;
            }
        }

        private string fnUpdateESubmission(string Update_Type, string Status_Id_Prev, string Status_Id_Next, ref bool ifSuccess)
        {
            DataTable dtCodeDetails = new DataTable("DataTypeUpdateESubmission");
            dtCodeDetails.Columns.Add("ROW_NUM", typeof(string));
            dtCodeDetails.Columns.Add("SUBMISSION_ID", typeof(string));
            dtCodeDetails.Columns.Add("RPT_ID", typeof(string));
            dtCodeDetails.Columns.Add("POSITION_DATE", typeof(string));
            dtCodeDetails.Columns.Add("TARGET_SUBMISSION_DATE", typeof(string));
            dtCodeDetails.Columns.Add("APPROVED_EXTENDED_DATE", typeof(string));

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //dtCodeDetails.Columns.Add("RESUBMISSION_NO", typeof(string));

            dtCodeDetails.Columns.Add("EXTENDED_ATTACHMENT_NAME", typeof(string));
            dtCodeDetails.Columns.Add("EXTENDED_REASON", typeof(string));
            dtCodeDetails.Columns.Add("ACTUAL_SUBMISSION_DATE", typeof(string));
            dtCodeDetails.Columns.Add("COMPLIANCE", typeof(string));

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //dtCodeDetails.Columns.Add("COMPLIANCE_REMARK", typeof(string));

            dtCodeDetails.Columns.Add("RRF_JUSTIFICATION", typeof(string));

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //dtCodeDetails.Columns.Add("CATEGORY_ISSUE_ID", typeof(string));
            //dtCodeDetails.Columns.Add("DESCRIPTION_ISSUE", typeof(string));
            //dtCodeDetails.Columns.Add("IMPACT_ISSUE", typeof(string));
            //dtCodeDetails.Columns.Add("CAUSAL", typeof(string));
            //dtCodeDetails.Columns.Add("ACTION_PLAN", typeof(string));
            //dtCodeDetails.Columns.Add("STATUS_UPDATE", typeof(string));

            //megatshamsul - 20170321 - SR1363674 - new field justification attachment
            dtCodeDetails.Columns.Add("JUSTIFICATION_ATTACHMENT_NAME", typeof(string));
            
            DataRow drCodeDetails = dtCodeDetails.NewRow();
            
            drCodeDetails["ROW_NUM"] = txtHdnROW_NUM.Text.ToString();
            drCodeDetails["SUBMISSION_ID"] = txtSUBMISSION_ID.Text.ToString();
            drCodeDetails["RPT_ID"] = txtRPT_ID.Text.ToString();
            drCodeDetails["POSITION_DATE"] = BusinessLogicClass.SetYYYYMMDD(txtPOSITION_DATE.Text.ToString());
            drCodeDetails["TARGET_SUBMISSION_DATE"] = BusinessLogicClass.SetYYYYMMDD(txtTARGET_SUBMISSION_DATE.Text.ToString());
            drCodeDetails["APPROVED_EXTENDED_DATE"] = BusinessLogicClass.SetYYYYMMDD(txtAPPROVED_EXTENDED_DATE.Text.ToString());

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            ////drCodeDetails["RESUBMISSION_NO"] = txtRESUBMISSION_NO.Text.ToString();
            //drCodeDetails["RESUBMISSION_NO"] = txtHdnRESUBMISSION_NO_updt.Text.ToString();  //have to do this as value is reset if updated from jquery

            drCodeDetails["EXTENDED_ATTACHMENT_NAME"] = fnGetUploadFilename(fuEXTENDED_ATTACHMENT);
            drCodeDetails["EXTENDED_REASON"] = txtEXTENDED_REASON.Text.ToString();
            drCodeDetails["ACTUAL_SUBMISSION_DATE"] = BusinessLogicClass.SetYYYYMMDD(txtACTUAL_SUBMISSION_DATE.Text.ToString());
            drCodeDetails["COMPLIANCE"] = txtHdnCOMPLIANCE.Text;    // ddlCOMPLIANCE.SelectedValue.ToString();  //have to do this as value is reset if updated from jquery

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //drCodeDetails["COMPLIANCE_REMARK"] = txtCOMPLIANCE_REMARK.Text.ToString();

            drCodeDetails["RRF_JUSTIFICATION"] = txtHdnRRF_JUSTIFICATION.Text;  // ddlRRF_JUSTIFICATION.SelectedValue.ToString();  //have to do this as value is reset if updated from jquery

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //drCodeDetails["CATEGORY_ISSUE_ID"] = ddlCATEGORY_ISSUE_ID.SelectedValue.ToString();
            //drCodeDetails["DESCRIPTION_ISSUE"] = txtDESCRIPTION_ISSUE.Text.ToString();
            //drCodeDetails["IMPACT_ISSUE"] = txtIMPACT_ISSUE.Text.ToString();
            //drCodeDetails["CAUSAL"] = txtCAUSAL.Text.ToString();
            //drCodeDetails["ACTION_PLAN"] = txtACTION_PLAN.Text.ToString();
            //drCodeDetails["STATUS_UPDATE"] = txtSTATUS_UPDATE.Text.ToString();

            //megatshamsul - 20170321 - SR1363674 - new field justification attachment
            drCodeDetails["JUSTIFICATION_ATTACHMENT_NAME"] = fnGetUploadFilename(fuJUSTIFICATION_ATTACHMENT);

            dtCodeDetails.Rows.Add(drCodeDetails);

            //megatshamsul - 20170321 - SR1363674 - add resubmission details
            DataTable dtCodeDetailsResubmission = new DataTable("DataTypeUpdateESubmissionResubmission");

            dtCodeDetailsResubmission.Columns.Add("ROW_NUM_SRC", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("RESUBMISSION_NO", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("RESUBMISSION_DATE", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("RRF_JUSTIFICATION", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("CATEGORY_ISSUE_ID", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("DESCRIPTION_ISSUE", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("IMPACT_ISSUE", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("CAUSAL", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("ACTION_PLAN", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("STATUS_UPDATE", typeof(string));
            dtCodeDetailsResubmission.Columns.Add("RESUBMISSION_ATTACHMENT_NAME", typeof(string));

            DataRow drCodeDetailsResubmission;
            TextBox TextBox1 = null;
            TextBox TextBox2 = null;
            TextBox TextBox3 = null;
            TextBox TextBox4 = null;
            TextBox TextBox5 = null;
            TextBox TextBox6 = null;
            DropDownList DropDownList1 = null;
            DropDownList DropDownList2 = null;
            FileUpload FileUpload1 = null;
            LinkButton LinkButton1 = null;
            string ObjectId = string.Empty;
            int x = 1;

            for (int y = 1; y <= 5; y++)
            {
                ObjectId = "txtRESUBMISSION_DATE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "ddlRESUBMISSION_JUSTIFICATION_" + y;
                DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                ObjectId = "ddlRESUBMISSION_CATEGORY_ISSUE_" + y;
                DropDownList2 = FindControlRecursive(Page, ObjectId) as DropDownList;

                ObjectId = "txtRESUBMISSION_DESCRIPTION_ISSUE_" + y;
                TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "txtRESUBMISSION_IMPACT_ISSUE_" + y;
                TextBox3 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "txtRESUBMISSION_CAUSAL_" + y;
                TextBox4 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "txtRESUBMISSION_ACTION_PLAN_" + y;
                TextBox5 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "txtRESUBMISSION_STATUS_UPDATE_" + y;
                TextBox6 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "fuRESUBMISSION_ATTACHMENT_" + y;
                FileUpload1 = FindControlRecursive(Page, ObjectId) as FileUpload;

                ObjectId = "lbRESUBMISSION_ATTACHMENT_NAME_" + y;
                LinkButton1 = FindControlRecursive(Page, ObjectId) as LinkButton;

                if (TextBox1 != null && DropDownList1 != null && DropDownList2 != null && TextBox2 != null && TextBox3 != null && TextBox4 != null && TextBox5 != null && TextBox6 != null && FileUpload1 != null && LinkButton1 != null)
                {
                    if (!String.IsNullOrEmpty(TextBox1.Text) && !String.IsNullOrEmpty(DropDownList1.SelectedValue))
                    {
                        drCodeDetailsResubmission = dtCodeDetailsResubmission.NewRow();

                        drCodeDetailsResubmission["ROW_NUM_SRC"] = txtHdnROW_NUM.Text.ToString();
                        drCodeDetailsResubmission["RESUBMISSION_NO"] = x.ToString();
                        drCodeDetailsResubmission["RESUBMISSION_DATE"] = BusinessLogicClass.SetYYYYMMDD(TextBox1.Text.ToString());
                        drCodeDetailsResubmission["RRF_JUSTIFICATION"] = DropDownList1.SelectedValue.ToString();
                        drCodeDetailsResubmission["CATEGORY_ISSUE_ID"] = DropDownList2.SelectedValue.ToString();
                        drCodeDetailsResubmission["DESCRIPTION_ISSUE"] = TextBox2.Text.ToString();
                        drCodeDetailsResubmission["IMPACT_ISSUE"] = TextBox3.Text.ToString();
                        drCodeDetailsResubmission["CAUSAL"] = TextBox4.Text.ToString();
                        drCodeDetailsResubmission["ACTION_PLAN"] = TextBox5.Text.ToString();
                        drCodeDetailsResubmission["STATUS_UPDATE"] = TextBox6.Text.ToString();
                        drCodeDetailsResubmission["RESUBMISSION_ATTACHMENT_NAME"] = fnGetUploadFilename(FileUpload1);

                        dtCodeDetailsResubmission.Rows.Add(drCodeDetailsResubmission);
                        x = x + 1;
                    }
                }
            }

            //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT + resubmission  details
            //string strMessage = BusinessLogicClass.fnUpdateESubmissionDetails(Update_Type, Status_Id_Prev, Status_Id_Next, dtCodeDetails, fuEXTENDED_ATTACHMENT, txtHdnRMV_ATTACHMENT.Text, Session["strUserId"].ToString(), ref ifSuccess);
            string strMessage = BusinessLogicClass.fnUpdateESubmissionDetails(Update_Type, Status_Id_Prev, Status_Id_Next, dtCodeDetails, dtCodeDetailsResubmission, fuEXTENDED_ATTACHMENT, txtHdnRMV_EXTENDED_ATTACHMENT.Text, fuJUSTIFICATION_ATTACHMENT, txtHdnRMV_JUSTIFICATION_ATTACHMENT.Text, fuRESUBMISSION_ATTACHMENT_1, txtHdnRMV_RESUBMISSION_ATTACHMENT_1.Text, fuRESUBMISSION_ATTACHMENT_2, txtHdnRMV_RESUBMISSION_ATTACHMENT_2.Text, fuRESUBMISSION_ATTACHMENT_3, txtHdnRMV_RESUBMISSION_ATTACHMENT_3.Text, fuRESUBMISSION_ATTACHMENT_4, txtHdnRMV_RESUBMISSION_ATTACHMENT_4.Text, fuRESUBMISSION_ATTACHMENT_5, txtHdnRMV_RESUBMISSION_ATTACHMENT_5.Text, Session["strUserId"].ToString(), ref ifSuccess);

            return strMessage;
        }

        private void fnResetEditForm()
        {
            txtSUBMISSION_ID.Text = "";
            txtSUBMISSION_ID.Enabled = false;

            txtRPT_ID.Text = "";
            txtRPT_ID.Enabled = false;

            txtRPT_NAME.Text = "";
            txtRPT_NAME.Enabled = false;

            txtPOSITION_DATE.Text = "";
            txtPOSITION_DATE.Enabled = false;

            txtTARGET_SUBMISSION_DATE.Text = "";
            txtTARGET_SUBMISSION_DATE.Enabled = false;

            txtSREF.Text = "";
            txtSREF.Enabled = false;

            txtUNIT_ID.Text = "";
            txtUNIT_ID.Enabled = false;

            txtENTITY_ID.Text = "";
            txtENTITY_ID.Enabled = false;

            txtFREQUENCY_ID.Text = "";
            txtFREQUENCY_ID.Enabled = false;

            txtSUBMISSION_MODE_ID.Text = "";
            txtSUBMISSION_MODE_ID.Enabled = false;

            txtAPPROVED_EXTENDED_DATE.Text = "";
            txtAPPROVED_EXTENDED_DATE.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //txtRESUBMISSION_NO.Text = "";
            //txtRESUBMISSION_NO.Enabled = false;

            lbEXTENDED_ATTACHMENT_NAME.Text = "";

            lblMandatoryEXTENDED_ATTACHMENT.Style.Remove("display");
            lblMandatoryEXTENDED_ATTACHMENT.Attributes.Add("style", "display:none");

            fuEXTENDED_ATTACHMENT.Enabled = false;

            lblMandatoryEXTENDED_REASON.Style.Remove("display");
            lblMandatoryEXTENDED_REASON.Attributes.Add("style", "display:none");

            txtEXTENDED_REASON.Text = "";
            txtEXTENDED_REASON.Enabled = false;

            txtACTUAL_SUBMISSION_DATE.Text = "";
            txtACTUAL_SUBMISSION_DATE.Enabled = false;

            ddlCOMPLIANCE.SelectedIndex = -1;
            ddlCOMPLIANCE.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
            fuJUSTIFICATION_ATTACHMENT.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
            lblMandatoryJUSTIFICATION_ATTACHMENT.Style.Remove("display");
            lblMandatoryJUSTIFICATION_ATTACHMENT.Attributes.Add("style", "display:none");

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //lblMandatoryCOMPLIANCE_REMARK.Style.Remove("display");
            //lblMandatoryCOMPLIANCE_REMARK.Attributes.Add("style", "display:none");

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //txtCOMPLIANCE_REMARK.Text = "";
            //txtCOMPLIANCE_REMARK.Enabled = false;

            ddlRRF_JUSTIFICATION.SelectedIndex = -1;
            ddlRRF_JUSTIFICATION.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - enable RRF JUSTIFICATION for edit
            lblMandatoryRRF_JUSTIFICATION.Style.Remove("display");
            lblMandatoryRRF_JUSTIFICATION.Attributes.Add("style", "display:none");

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //lblMandatoryCATEGORY_ISSUE_ID.Style.Remove("display");
            //lblMandatoryCATEGORY_ISSUE_ID.Attributes.Add("style", "display:none");

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //ddlCATEGORY_ISSUE_ID.SelectedIndex = -1;
            //ddlCATEGORY_ISSUE_ID.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //lblMandatoryDESCRIPTION_ISSUE.Style.Remove("display");
            //lblMandatoryDESCRIPTION_ISSUE.Attributes.Add("style", "display:none");

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //txtDESCRIPTION_ISSUE.Text = "";
            //txtDESCRIPTION_ISSUE.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //lblMandatoryIMPACT_ISSUE.Style.Remove("display");
            //lblMandatoryIMPACT_ISSUE.Attributes.Add("style", "display:none");

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //txtIMPACT_ISSUE.Text = "";
            //txtIMPACT_ISSUE.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //lblMandatoryCAUSAL.Style.Remove("display");
            //lblMandatoryCAUSAL.Attributes.Add("style", "display:none");

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //txtCAUSAL.Text = "";
            //txtCAUSAL.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //lblMandatoryACTION_PLAN.Style.Remove("display");
            //lblMandatoryACTION_PLAN.Attributes.Add("style", "display:none");

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //txtACTION_PLAN.Text = "";
            //txtACTION_PLAN.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //txtSTATUS_UPDATE.Text = "";
            //txtSTATUS_UPDATE.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            fnEnableResubmissionFields(false, true);

            ddlSTATUS_ID.SelectedIndex = -1;
            ddlSTATUS_ID.Enabled = false;

            txtCREATE_DATE.Text = "";
            txtCREATE_DATE.Enabled = false;

            txtPREPARER_ID.Text = "";
            txtPREPARER_ID.Enabled = false;

            txtPREPARER_DATE.Text = "";
            txtPREPARER_DATE.Enabled = false;

            txtAPPROVER_ID.Text = "";
            txtAPPROVER_ID.Enabled = false;

            txtAPPROVER_DATE.Text = "";
            txtAPPROVER_DATE.Enabled = false;

            txtAPPROVER_FGT_ID.Text = "";
            txtAPPROVER_FGT_ID.Enabled = false;

            txtAPPROVER_FGT_DATE.Text = "";
            txtAPPROVER_FGT_DATE.Enabled = false;

            txtREJECT_REASON.Text = "";
            txtREJECT_REASON.Enabled = false;

            btnUpdateESubmission.Enabled = false;
            btnUpdateESubmission.Visible = false;
            lblUpdateButtonSpace.Visible = false;
            btnUpdateSubmitESubmission.Enabled = false;
            btnUpdateSubmitESubmission.Visible = false;
            lblUpdateSubmitButtonSpace.Visible = false;

            //e-submission do not support deletion/discontinue
            //btnDeleteESubmission.Enabled = false;
            //btnDeleteESubmission.Visible = false;
            //lblDeleteButtonSpace.Visible = false;
            //btnDeleteSubmitESubmission.Enabled = false;
            //btnDeleteSubmitESubmission.Visible = false;
            //lblDeleteSubmitButtonSpace.Visible = false;

            btnApproval.Enabled = false;
            btnApproval.Visible = false;
            lblApprovalButtonSpace.Visible = false;
            btnReject.Enabled = false;
            btnReject.Visible = false;
        }

        private void EnableFieldsForAddEdit(string Update_Type, bool ifEnable)
        {
            if (ifEnable)
            {
                lblMandatoryACTUAL_SUBMISSION_DATE.Style.Remove("display");
                lblMandatoryACTUAL_SUBMISSION_DATE.Attributes.Add("style", "display:inline");

                if (ddlCOMPLIANCE.SelectedValue == "N")
                {
                    //megatshamsul - 20170317 - SR1363674 - not mandatory anymore
                    //lblMandatoryEXTENDED_ATTACHMENT.Style.Remove("display");
                    //lblMandatoryEXTENDED_ATTACHMENT.Attributes.Add("style", "display:inline");
                    //lblMandatoryEXTENDED_REASON.Style.Remove("display");
                    //lblMandatoryEXTENDED_REASON.Attributes.Add("style", "display:inline");

                    //megatshamsul - 20170317 - SR1363674 - mandatory due to non-compliance
                    lblMandatoryRRF_JUSTIFICATION.Style.Remove("display");
                    lblMandatoryRRF_JUSTIFICATION.Attributes.Add("style", "display:inline");

                    //megatshamsul - 20170317 - SR1363674 - mandatory due to non-compliance
                    if (txtSREF.Text == SREF_Yes_MP || txtSREF.Text == SREF_Yes_NMP)
                    {
                        lblMandatoryJUSTIFICATION_ATTACHMENT.Style.Remove("display");
                        lblMandatoryJUSTIFICATION_ATTACHMENT.Attributes.Add("style", "display:inline");
                    }
                    else
                    {
                        lblMandatoryJUSTIFICATION_ATTACHMENT.Style.Remove("display");
                        lblMandatoryJUSTIFICATION_ATTACHMENT.Attributes.Add("style", "display:none");
                    }
                    
                    //lblMandatoryEXTENDED_REASON.Style.Remove("display");
                    //lblMandatoryEXTENDED_REASON.Attributes.Add("style", "display:inline")

                    //megatshamsul - 20170317 - SR1363674 - obsolete fields
                    //lblMandatoryCOMPLIANCE_REMARK.Style.Remove("display");
                    //lblMandatoryCOMPLIANCE_REMARK.Attributes.Add("style", "display:inline");
                    //lblMandatoryCATEGORY_ISSUE_ID.Style.Remove("display");
                    //lblMandatoryCATEGORY_ISSUE_ID.Attributes.Add("style", "display:inline");
                    //lblMandatoryDESCRIPTION_ISSUE.Style.Remove("display");
                    //lblMandatoryDESCRIPTION_ISSUE.Attributes.Add("style", "display:inline");
                    //lblMandatoryIMPACT_ISSUE.Style.Remove("display");
                    //lblMandatoryIMPACT_ISSUE.Attributes.Add("style", "display:inline");
                    //lblMandatoryCAUSAL.Style.Remove("display");
                    //lblMandatoryCAUSAL.Attributes.Add("style", "display:inline");
                    //lblMandatoryACTION_PLAN.Style.Remove("display");
                    //lblMandatoryACTION_PLAN.Attributes.Add("style", "display:inline");
                }
                else
                {
                    //megatshamsul - 20170317 - SR1363674 - not mandatory anymore
                    //lblMandatoryEXTENDED_ATTACHMENT.Style.Remove("display");
                    //lblMandatoryEXTENDED_ATTACHMENT.Attributes.Add("style", "display:none");
                    //lblMandatoryEXTENDED_REASON.Style.Remove("display");
                    //lblMandatoryEXTENDED_REASON.Attributes.Add("style", "display:none");

                    //megatshamsul - 20170317 - SR1363674 - mandatory due to non-compliance
                    lblMandatoryRRF_JUSTIFICATION.Style.Remove("display");
                    lblMandatoryRRF_JUSTIFICATION.Attributes.Add("style", "display:none");
                    lblMandatoryJUSTIFICATION_ATTACHMENT.Style.Remove("display");
                    lblMandatoryJUSTIFICATION_ATTACHMENT.Attributes.Add("style", "display:none");

                    //megatshamsul - 20170317 - SR1363674 - obsolete fields
                    //lblMandatoryCOMPLIANCE_REMARK.Style.Remove("display");
                    //lblMandatoryCOMPLIANCE_REMARK.Attributes.Add("style", "display:none");
                    //lblMandatoryCATEGORY_ISSUE_ID.Style.Remove("display");
                    //lblMandatoryCATEGORY_ISSUE_ID.Attributes.Add("style", "display:none");
                    //lblMandatoryDESCRIPTION_ISSUE.Style.Remove("display");
                    //lblMandatoryDESCRIPTION_ISSUE.Attributes.Add("style", "display:none");
                    //lblMandatoryIMPACT_ISSUE.Style.Remove("display");
                    //lblMandatoryIMPACT_ISSUE.Attributes.Add("style", "display:none");
                    //lblMandatoryCAUSAL.Style.Remove("display");
                    //lblMandatoryCAUSAL.Attributes.Add("style", "display:none");
                    //lblMandatoryACTION_PLAN.Style.Remove("display");
                    //lblMandatoryACTION_PLAN.Attributes.Add("style", "display:none");
                }
            }
            else
            {
                lblMandatoryACTUAL_SUBMISSION_DATE.Style.Remove("display");
                lblMandatoryACTUAL_SUBMISSION_DATE.Attributes.Add("style", "display:none");

                //megatshamsul - 20170317 - SR1363674 - not mandatory anymore
                //lblMandatoryEXTENDED_ATTACHMENT.Style.Remove("display");
                //lblMandatoryEXTENDED_ATTACHMENT.Attributes.Add("style", "display:none");
                //lblMandatoryEXTENDED_REASON.Style.Remove("display");
                //lblMandatoryEXTENDED_REASON.Attributes.Add("style", "display:none");

                //megatshamsul - 20170317 - SR1363674 - mandatory due to non-compliance
                lblMandatoryRRF_JUSTIFICATION.Style.Remove("display");
                lblMandatoryRRF_JUSTIFICATION.Attributes.Add("style", "display:none");
                lblMandatoryJUSTIFICATION_ATTACHMENT.Style.Remove("display");
                lblMandatoryJUSTIFICATION_ATTACHMENT.Attributes.Add("style", "display:none");

                //megatshamsul - 20170317 - SR1363674 - obsolete fields
                //lblMandatoryCOMPLIANCE_REMARK.Style.Remove("display");
                //lblMandatoryCOMPLIANCE_REMARK.Attributes.Add("style", "display:none");
                //lblMandatoryCATEGORY_ISSUE_ID.Style.Remove("display");
                //lblMandatoryCATEGORY_ISSUE_ID.Attributes.Add("style", "display:none");
                //lblMandatoryDESCRIPTION_ISSUE.Style.Remove("display");
                //lblMandatoryDESCRIPTION_ISSUE.Attributes.Add("style", "display:none");
                //lblMandatoryIMPACT_ISSUE.Style.Remove("display");
                //lblMandatoryIMPACT_ISSUE.Attributes.Add("style", "display:none");
                //lblMandatoryCAUSAL.Style.Remove("display");
                //lblMandatoryCAUSAL.Attributes.Add("style", "display:none");
                //lblMandatoryACTION_PLAN.Style.Remove("display");
                //lblMandatoryACTION_PLAN.Attributes.Add("style", "display:none");
            }

            txtAPPROVED_EXTENDED_DATE.Enabled = ifEnable;
            fuEXTENDED_ATTACHMENT.Enabled = ifEnable;
            txtEXTENDED_REASON.Enabled = ifEnable;
            txtACTUAL_SUBMISSION_DATE.Enabled = ifEnable;
            ddlCOMPLIANCE.Enabled = false;

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //txtCOMPLIANCE_REMARK.Enabled = ifEnable;

            //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
            fuJUSTIFICATION_ATTACHMENT.Enabled = ifEnable;

            //megatshamsul - 20170317 - SR1363674 - enable RRF JUSTIFICATION for edit
            //ddlRRF_JUSTIFICATION.Enabled = false;
            ddlRRF_JUSTIFICATION.Enabled = ifEnable;

            //megatshamsul - 20170317 - SR1363674 - obsolete fields
            //ddlCATEGORY_ISSUE_ID.Enabled = ifEnable;
            //txtDESCRIPTION_ISSUE.Enabled = ifEnable;
            //txtIMPACT_ISSUE.Enabled = ifEnable;
            //txtCAUSAL.Enabled = ifEnable;
            //txtACTION_PLAN.Enabled = ifEnable;
            //txtSTATUS_UPDATE.Enabled = ifEnable;

            //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
            fnEnableResubmissionFields(ifEnable, false);

            ddlSTATUS_ID.Enabled = false;

            txtCREATE_DATE.Enabled = false;
            txtPREPARER_ID.Enabled = false;
            txtPREPARER_DATE.Enabled = false;
            txtAPPROVER_ID.Enabled = false;
            txtAPPROVER_DATE.Enabled = false;
            txtAPPROVER_FGT_ID.Enabled = false;
            txtAPPROVER_FGT_DATE.Enabled = false;
            txtREJECT_REASON.Enabled = false;

            btnUpdateESubmission.Enabled = ifEnable;
            btnUpdateESubmission.Visible = ifEnable;
            lblUpdateButtonSpace.Visible = ifEnable;
            btnUpdateSubmitESubmission.Enabled = ifEnable;
            btnUpdateSubmitESubmission.Visible = ifEnable;
            lblUpdateSubmitButtonSpace.Visible = ifEnable;

            //e-submission do not support deletion/discontinue
            //btnDeleteESubmission.Enabled = ifEnable;
            //btnDeleteESubmission.Visible = ifEnable;
            //lblDeleteButtonSpace.Visible = ifEnable;
            //btnDeleteSubmitESubmission.Enabled = ifEnable;
            //btnDeleteSubmitESubmission.Visible = ifEnable;
            //lblDeleteSubmitButtonSpace.Visible = ifEnable;

            btnApproval.Enabled = false;
            btnApproval.Visible = false;
            lblApprovalButtonSpace.Visible = false;
            btnReject.Enabled = false;
            btnReject.Visible = false;
        }

        //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
        private void fnEnableResubmissionFields(bool ifEnable, bool ifReset)
        {
            DropDownList DropDownList1 = null;
            TextBox TextBox1 = null;
            FileUpload FileUpload1 = null;
            LinkButton LinkButton1 = null;
            string ObjectId = string.Empty;

            for (int y = 1; y <= 5; y++)
            {
                ObjectId = "txtRESUBMISSION_DATE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null)
                {
                    TextBox1.Enabled = ifEnable;

                    if (ifReset)
                        TextBox1.Text = string.Empty;
                }

                ObjectId = "ddlRESUBMISSION_JUSTIFICATION_" + y;
                DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                if (DropDownList1 != null)
                {
                    DropDownList1.Enabled = ifEnable;

                    if (ifReset)
                        DropDownList1.SelectedIndex = -1;
                }

                ObjectId = "ddlRESUBMISSION_CATEGORY_ISSUE_" + y;
                DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                if (DropDownList1 != null)
                {
                    DropDownList1.Enabled = ifEnable;

                    if (ifReset)
                        DropDownList1.SelectedIndex = -1;
                }

                ObjectId = "txtRESUBMISSION_DESCRIPTION_ISSUE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null)
                {
                    TextBox1.Enabled = ifEnable;

                    if (ifReset)
                        TextBox1.Text = string.Empty;
                }

                ObjectId = "txtRESUBMISSION_IMPACT_ISSUE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null)
                {
                    TextBox1.Enabled = ifEnable;

                    if (ifReset)
                        TextBox1.Text = string.Empty;
                }

                ObjectId = "txtRESUBMISSION_CAUSAL_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null)
                {
                    TextBox1.Enabled = ifEnable;

                    if (ifReset)
                        TextBox1.Text = string.Empty;
                }

                ObjectId = "txtRESUBMISSION_ACTION_PLAN_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null)
                {
                    TextBox1.Enabled = ifEnable;

                    if (ifReset)
                        TextBox1.Text = string.Empty;
                }

                ObjectId = "txtRESUBMISSION_STATUS_UPDATE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null)
                {
                    TextBox1.Enabled = ifEnable;

                    if (ifReset)
                        TextBox1.Text = string.Empty;
                }

                ObjectId = "fuRESUBMISSION_ATTACHMENT_" + y;
                FileUpload1 = FindControlRecursive(Page, ObjectId) as FileUpload;

                ObjectId = "lbRESUBMISSION_ATTACHMENT_NAME_" + y;
                LinkButton1 = FindControlRecursive(Page, ObjectId) as LinkButton;

                if (FileUpload1 != null && LinkButton1 != null)
                {
                    FileUpload1.Enabled = ifEnable;
                    //LinkButton1.Enabled = ifEnable;

                    if (ifReset)
                        LinkButton1.Text = string.Empty;
                }
            }
        }

        private bool ValidateFieldsAddEdit(string Update_Type)
        {
            string sUploadLimit = ConfigurationManager.AppSettings["UPLOAD_LIMIT"].ToString();
            int iUploadLimit = Int32.Parse(sUploadLimit);

            if (string.IsNullOrEmpty(txtACTUAL_SUBMISSION_DATE.Text))
            {
                ShowMessage("This is mandatory field, input is required - ACTUAL SUBMISSION DATE", txtACTUAL_SUBMISSION_DATE.ClientID.ToString());
                return false;
            }

            #region Compliance Checking

            //if (ddlCOMPLIANCE.SelectedValue == "N")
            if (txtHdnCOMPLIANCE.Text == "N")    //have to do this as value is reset if updated from jquery
            {
                //megatshamsul - 20170321 - SR1363674 - check mandatory fields for non-compliance
                if (string.IsNullOrEmpty(ddlRRF_JUSTIFICATION.SelectedValue))
                {
                    ShowMessage("This is mandatory field, input is required - RRF JUSTIFICATION", ddlRRF_JUSTIFICATION.ClientID.ToString());
                    return false;
                }

                //megatshamsul - 20170321 - SR1363674 - check mandatory fields for non-compliance
                if (txtSREF.Text == SREF_Yes_MP || txtSREF.Text == SREF_Yes_NMP)
                {
                    if (fuJUSTIFICATION_ATTACHMENT.HasFile)
                    { 
                        //do nothing
                    }
                    else if (txtHdnRMV_EXTENDED_ATTACHMENT.Text == "1")
                    {
                        lbJUSTIFICATION_ATTACHMENT_NAME.Text = string.Empty;
                        ShowMessage("This is mandatory field, input is required - JUSTIFICATION ATTACHMENT", fuJUSTIFICATION_ATTACHMENT.ClientID.ToString());
                        return false;
                    }
                    else if (lbJUSTIFICATION_ATTACHMENT_NAME.Text.Length > 0 && lbJUSTIFICATION_ATTACHMENT_NAME.Enabled)
                    {
                        //do nothing
                    }
                    else
                    {
                        ShowMessage("This is mandatory field, input is required - JUSTIFICATION ATTACHMENT", fuJUSTIFICATION_ATTACHMENT.ClientID.ToString());
                        return false;
                    }
                }
                
                //megatshamsul - 20170317 - SR1363674 - obsolete fields
                //if (string.IsNullOrEmpty(txtCOMPLIANCE_REMARK.Text))
                //{
                //    ShowMessage("This is mandatory field, input is required - COMPLIANCE REMARK", txtCOMPLIANCE_REMARK.ClientID.ToString());
                //    return false;
                //}

                //megatshamsul - 20170317 - SR1363674 - obsolete fields
                //if (string.IsNullOrEmpty(ddlCATEGORY_ISSUE_ID.SelectedValue))
                //{
                //    ShowMessage("This is mandatory field, input is required - CATEGORY_ISSUE_ID", ddlCATEGORY_ISSUE_ID.ClientID.ToString());
                //    return false;
                //}

                //megatshamsul - 20170317 - SR1363674 - obsolete fields
                //if (string.IsNullOrEmpty(txtDESCRIPTION_ISSUE.Text))
                //{
                //    ShowMessage("This is mandatory field, input is required - DESCRIPTION OF ISSUE", txtDESCRIPTION_ISSUE.ClientID.ToString());
                //    return false;
                //}

                //megatshamsul - 20170317 - SR1363674 - obsolete fields
                //if (string.IsNullOrEmpty(txtIMPACT_ISSUE.Text))
                //{
                //    ShowMessage("This is mandatory field, input is required - IMPACT OF ISSUE", txtIMPACT_ISSUE.ClientID.ToString());
                //    return false;
                //}

                //megatshamsul - 20170317 - SR1363674 - obsolete fields
                //if (string.IsNullOrEmpty(txtCAUSAL.Text))
                //{
                //    ShowMessage("This is mandatory field, input is required - CAUSAL", txtCAUSAL.ClientID.ToString());
                //    return false;
                //}

                //megatshamsul - 20170317 - SR1363674 - obsolete fields
                //if (string.IsNullOrEmpty(txtACTION_PLAN.Text))
                //{
                //    ShowMessage("This is mandatory field, input is required - ACTION PLAN", txtACTION_PLAN.ClientID.ToString());
                //    return false;
                //}
            }

            //megatshamsul - 20170321 - SR1363674 - check attachment field for non-compliance
            if (fuJUSTIFICATION_ATTACHMENT.HasFile)
            {
                txtHdnRMV_JUSTIFICATION_ATTACHMENT.Text = "0";

                if (fuJUSTIFICATION_ATTACHMENT.HasFile)
                {
                    if (fuJUSTIFICATION_ATTACHMENT.PostedFile.ContentLength < iUploadLimit)
                    {
                        string ext = Path.GetExtension(fuJUSTIFICATION_ATTACHMENT.FileName).ToUpper();
                        bool ifOK = false;

                        switch (ext)
                        {
                            case ".PDF":
                            case ".JPG":
                            case ".JPEG":
                            case ".GIF":
                                ifOK = true; break;
                            default:
                                ifOK = false; break;
                        }

                        if (!ifOK)
                        {
                            ShowMessage("Please select correct file format - PDF/JPG/JPEG/GIF", fuJUSTIFICATION_ATTACHMENT.ClientID.ToString());
                            return false;
                        }
                        //else
                        //    txtHdnRMV_JUSTIFICATION_ATTACHMENT.Text = "1";
                    }
                    else
                    {
                        ShowMessage("Please select file with size less than 2MB", fuJUSTIFICATION_ATTACHMENT.ClientID.ToString());
                        return false;
                    }
                }
            }

            #endregion

            #region Approved Extended Checking

            //megatshamsul - 20170321 - SR1363674 - check mandatory fields for approved extended
            if (!string.IsNullOrEmpty(txtAPPROVED_EXTENDED_DATE.Text))
            {
                if (string.IsNullOrEmpty(txtEXTENDED_REASON.Text))
                {
                    ShowMessage("This is mandatory field, input is required - EXTENDED REASON", txtEXTENDED_REASON.ClientID.ToString());
                    return false;
                }

                if (fuEXTENDED_ATTACHMENT.HasFile)
                {
                    //do nothing
                }
                else if (txtHdnRMV_EXTENDED_ATTACHMENT.Text == "1")
                {
                    lbEXTENDED_ATTACHMENT_NAME.Text = string.Empty;
                    ShowMessage("This is mandatory field, input is required - EXTENDED ATTACHMENT", fuEXTENDED_ATTACHMENT.ClientID.ToString());
                    return false;
                }
                else if (lbEXTENDED_ATTACHMENT_NAME.Text.Length > 0 && lbEXTENDED_ATTACHMENT_NAME.Enabled)
                {
                    //do nothing
                }
                else
                {
                    ShowMessage("This is mandatory field, input is required - EXTENDED ATTACHMENT", fuEXTENDED_ATTACHMENT.ClientID.ToString());
                    return false;
                }
            }

            //megatshamsul - 20170321 - SR1363674 - check attachment field for approved extended
            if (fuEXTENDED_ATTACHMENT.HasFile)
            {
                //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
                //txtHdnRMV_ATTACHMENT.Text = "0";
                txtHdnRMV_EXTENDED_ATTACHMENT.Text = "0";

                if (fuEXTENDED_ATTACHMENT.HasFile)
                {
                    if (fuEXTENDED_ATTACHMENT.PostedFile.ContentLength < iUploadLimit)
                    {
                        string ext = Path.GetExtension(fuEXTENDED_ATTACHMENT.FileName).ToUpper();
                        bool ifOK = false;

                        switch (ext)
                        {
                            case ".PDF":
                            case ".JPG":
                            case ".JPEG":
                            case ".GIF":
                                ifOK = true; break;
                            default:
                                ifOK = false; break;
                        }

                        if (!ifOK)
                        {
                            ShowMessage("Please select correct file format - PDF/JPG/JPEG/GIF", fuEXTENDED_ATTACHMENT.ClientID.ToString());
                            return false;
                        }
                        //megatshamsul - 20170317 - SR1363674 - fix attachment checking issue
                        //else
                        //{
                        //    //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT
                        //    //txtHdnRMV_ATTACHMENT.Text = "1";
                        //    txtHdnRMV_EXTENDED_ATTACHMENT.Text = "1";
                        //}
                    }
                    else
                    {
                        ShowMessage("Please select file with size less than 2MB", fuEXTENDED_ATTACHMENT.ClientID.ToString());
                        return false;
                    }
                }
            }

            #endregion

            #region Resubmission Checking

            DropDownList DropDownList1 = null;
            TextBox TextBox1 = null;
            TextBox TextBox2 = null;
            FileUpload FileUpload1 = null;
            LinkButton LinkButton1 = null;
            string ObjectId = string.Empty;
            string sDate = string.Empty;
            bool ifDateOK = false;
            
            for (int y = 1; y <= 5; y++)
            {
                ObjectId = "txtRESUBMISSION_DATE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null)
                {
                    if (!string.IsNullOrEmpty(TextBox1.Text) && string.IsNullOrEmpty(txtACTUAL_SUBMISSION_DATE.Text))
                    {
                        TabContainerESubmission.ActiveTab = TabPanelResubmission;
                        ShowMessage("For any resubmission, this is mandatory field, input is required - ACTUAL SUBMISSION DATE", txtACTUAL_SUBMISSION_DATE.ClientID.ToString());
                        return false;
                    }
                    else if (!string.IsNullOrEmpty(TextBox1.Text))
                    {
                        if (y == 1 || string.IsNullOrEmpty(sDate))
                        {
                            sDate = TextBox1.Text;
                            ifDateOK = true;
                        }
                        else
                            ifDateOK = BusinessLogicClass.fnValidateDatesRange(sDate, TextBox1.Text);
                        
                        if (ifDateOK)
                        {
                            ObjectId = "ddlRESUBMISSION_JUSTIFICATION_" + y;
                            DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                            if (DropDownList1 != null)
                            {
                                if (string.IsNullOrEmpty(DropDownList1.SelectedValue))
                                {
                                    TabContainerESubmission.ActiveTab = TabPanelResubmission;
                                    ShowMessage("This is mandatory field, input is required - RRF JUSTIFICATION", DropDownList1.ClientID.ToString());
                                    return false;
                                }
                            }

                            if (txtSREF.Text == SREF_Yes_MP || txtSREF.Text == SREF_Yes_NMP)
                            {
                                ObjectId = "fuRESUBMISSION_ATTACHMENT_" + y;
                                FileUpload1 = FindControlRecursive(Page, ObjectId) as FileUpload;

                                ObjectId = "lbRESUBMISSION_ATTACHMENT_NAME_" + y;
                                LinkButton1 = FindControlRecursive(Page, ObjectId) as LinkButton;

                                ObjectId = "txtHdnRMV_RESUBMISSION_ATTACHMENT_" + y;
                                TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                                if (FileUpload1 != null && LinkButton1 != null && TextBox2 != null)
                                {
                                    if (FileUpload1.HasFile)
                                    {
                                        //do nothing
                                    }
                                    else if (TextBox2.Text == "1")
                                    {
                                        LinkButton1.Text = string.Empty;
                                        TabContainerESubmission.ActiveTab = TabPanelResubmission;
                                        ShowMessage("This is mandatory field, input is required - RESUBMISSION ATTACHMENT", FileUpload1.ClientID.ToString());
                                        return false;
                                    }
                                    else if (LinkButton1.Text.Length > 0 && LinkButton1.Enabled)
                                    {
                                        //do nothing
                                    }
                                    else
                                    {
                                        TabContainerESubmission.ActiveTab = TabPanelResubmission;
                                        ShowMessage("This is mandatory field, input is required - RESUBMISSION ATTACHMENT", FileUpload1.ClientID.ToString());
                                        return false;
                                    }
                                }
                            }
                        }
                        else
                        {
                            TabContainerESubmission.ActiveTab = TabPanelResubmission;
                            ShowMessage("Current Resubmission Date must be greater than previous Resubmission Date", TextBox1.ClientID.ToString());
                            return false;
                        }
                    }
                }
            }

            #endregion

            if (Update_Type != "I")
            {
                if (string.IsNullOrEmpty(ddlSTATUS_ID.SelectedValue))
                {
                    ShowMessage("Missing STATUS ID", ddlSTATUS_ID.ClientID.ToString());
                    return false;
                }
            }

            return true;
        }

        private Control FindControlRecursive(Control root, string id)
        {
            if (root.ID == id) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, id);
                if (t != null) return t;
            }
            return null;
        }

        private string fnGetUploadFilename(FileUpload FileUploadControl)
        {
            string sFilename = string.Empty;

            try
            {
                if (FileUploadControl.HasFile)
                    sFilename = FileUploadControl.FileName;
            }
            catch (Exception ex)
            { }

            return sFilename;
        }

        #endregion

        #region Approval

        protected void btnApproval_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsApproval("A"))
            {
                bool ifSuccess = false;

                //megatshamsul - 20170323 - SR1363674 - set STATUS_ID 'AP2' if COMPLIANCE='Y'
                //ShowMessage(BusinessLogicClass.fnApproveESubmission("A", txtSUBMISSION_ID.Text, ddlSTATUS_ID.SelectedValue, txtHdnROW_NUM.Text, txtREJECT_REASON.Text, Session["strUserId"].ToString(), Session["strRoleId"].ToString(), ref ifSuccess), string.Empty);
                ShowMessage(BusinessLogicClass.fnApproveESubmission("A", txtSUBMISSION_ID.Text, ddlSTATUS_ID.SelectedValue, txtHdnROW_NUM.Text, txtREJECT_REASON.Text, ddlCOMPLIANCE.SelectedValue, Session["strUserId"].ToString(), Session["strRoleId"].ToString(), ref ifSuccess), string.Empty);

                string sRptName = txtRPT_NAME.Text;
                string sUnitId = string.Empty;

                if (Session["strRoleId"].ToString() == "Approver")
                    sUnitId = Session["strUnitId"].ToString();
                else if (Session["strRoleId"].ToString() == "FGTAppvr")
                    sUnitId = txtHdnUNIT_ID.Text;

                fnResetEditForm();
                fnBindListing(false);

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(sUnitId, "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(sUnitId, "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = string.Empty;
                    string sEmailBody = string.Empty;

                    if (Session["strRoleId"].ToString() == "Approver")
                    {
                        sEmailSubject = "E-Submission Has Been Submitted For Finance Governance Team’s Approval";
                        sEmailBody = "E-Submission Report Name " + sRptName + " has been approved by Approver " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and is now in Finance Governance’s queue. Please act accordingly.";
                    }
                    else if (Session["strRoleId"].ToString() == "FGTAppvr")
                    {
                        sEmailSubject = "E-Submission Has Been Successfully Approved";
                        sEmailBody = "E-Submission Report Name " + sRptName + " has been approved by Finance Governance " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and will be consolidated into Dashboard.";
                    }

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                TabContainerESubmission.ActiveTab = TabPanelListing;
            }
        }

        protected void btnReject_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsApproval("R"))
            {
                bool ifSuccess = false;

                //megatshamsul - 20170323 - SR1363674 - set STATUS_ID 'AP2' if COMPLIANCE='Y'
                //ShowMessage(BusinessLogicClass.fnApproveESubmission("R", txtSUBMISSION_ID.Text, ddlSTATUS_ID.SelectedValue, txtHdnROW_NUM.Text, txtREJECT_REASON.Text, Session["strUserId"].ToString(), Session["strRoleId"].ToString(), ref ifSuccess), string.Empty);
                ShowMessage(BusinessLogicClass.fnApproveESubmission("R", txtSUBMISSION_ID.Text, ddlSTATUS_ID.SelectedValue, txtHdnROW_NUM.Text, txtREJECT_REASON.Text, ddlCOMPLIANCE.SelectedValue, Session["strUserId"].ToString(), Session["strRoleId"].ToString(), ref ifSuccess), string.Empty);

                string sRptName = txtRPT_NAME.Text;
                string sUnitId = string.Empty;

                if (Session["strRoleId"].ToString() == "Approver")
                    sUnitId = Session["strUnitId"].ToString();
                else if (Session["strRoleId"].ToString() == "FGTAppvr")
                    sUnitId = txtHdnUNIT_ID.Text;

                fnResetEditForm();
                fnBindListing(false);

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(sUnitId, "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(sUnitId, "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = string.Empty;
                    string sEmailBody = string.Empty;

                    if (Session["strRoleId"].ToString() == "Approver")
                    {
                        sEmailSubject = "E-Submission Has Been Rejected by Approver and Now Available at Preparer’s REJECT BUCKET";
                        sEmailBody = "E-Submission Report Name " + sRptName + " has been rejected by Approver. Please act accordingly.";
                    }
                    else if (Session["strRoleId"].ToString() == "FGTAppvr")
                    {
                        sEmailSubject = "E-Submission Has Been Rejected by FG and Now Available at Preparer’s REJECT BUCKET";
                        sEmailBody = "E-Submission Report Name " + sRptName + " has been rejected by FG. Please act accordingly.";
                    }

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                TabContainerESubmission.ActiveTab = TabPanelListing;
            }
        }

        private bool ValidateFieldsApproval(string Action_Type)
        {
            if (string.IsNullOrEmpty(txtSUBMISSION_ID.Text))
            {
                ShowMessage("Missing SUBMISSION_ID", txtSUBMISSION_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlSTATUS_ID.SelectedValue))
            {
                ShowMessage("Missing STATUS_ID", ddlSTATUS_ID.ClientID.ToString());
                return false;
            }

            if (Action_Type == "R" && string.IsNullOrEmpty(txtREJECT_REASON.Text))
            {
                ShowMessage("This is mandatory field, input is required - REJECT_REASON", txtREJECT_REASON.ClientID.ToString());
                return false;
            }

            return true;
        }

        #endregion

        #region Print & Export

        protected void btnPrint_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    string strPrintRptId = "";
                    string strPrintRptName = "";
                    string strPrintRegulatorId = "";
                    string strPrintSREF = "";
                    string strPrintFrequencyId = "";
                    string strPrintStatusId = "";
                    string strPrintCreateDate = "";

                    using (StringWriter sw = new StringWriter())
                    {
                        using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                        {
                            //To Export all pages
                            grdvwListing.AllowPaging = false;
                            grdvwListing.AutoGenerateSelectButton = false;

                            // get data from gridview
                            this.fnBindListing(true);

                            if (txtFilterRPT_ID.Text.Length > 0)
                                strPrintRptId = txtFilterRPT_ID.Text;
                            else
                                strPrintRptId = "All Report Ids";

                            if (txtFilterRPT_NAME.Text.Length > 0)
                                strPrintRptName = txtFilterRPT_NAME.Text;
                            else
                                strPrintRptName = "All Report Names";

                            if (ddlFilterREGULATOR_ID.SelectedValue.Length > 0)
                                strPrintRegulatorId = ddlFilterREGULATOR_ID.SelectedItem.Text;
                            else
                                strPrintRegulatorId = "All Regulators";

                            if (ddlFilterSREF.SelectedValue.Length > 0)
                                strPrintSREF = ddlFilterSREF.SelectedItem.Text;
                            else
                                strPrintSREF = "All SREF";

                            if (ddlFilterFREQUENCY_ID.SelectedValue.Length > 0)
                                strPrintFrequencyId = ddlFilterFREQUENCY_ID.SelectedItem.Text;
                            else
                                strPrintFrequencyId = "All Frequencies";

                            if (!chkbxFilterStatusAll.Checked)
                            {
                                strPrintStatusId = string.Empty;

                                if (chkbxFilterStatusDraft.Checked)
                                    strPrintStatusId = "Draft";

                                if (chkbxFilterStatusNew.Checked)
                                {
                                    if (strPrintStatusId.Length > 0)
                                        strPrintStatusId = strPrintStatusId + "/New/Update/Request For Discontinue";
                                    else
                                        strPrintStatusId = "New/Update/Request For Discontinue";
                                }

                                if (chkbxFilterStatusApproved.Checked)
                                {
                                    if (strPrintStatusId.Length > 0)
                                        strPrintStatusId = strPrintStatusId + "/Approved";
                                    else
                                        strPrintStatusId = "Approved";
                                }

                                if (chkbxFilterStatusRejected.Checked)
                                {
                                    if (strPrintStatusId.Length > 0)
                                        strPrintStatusId = strPrintStatusId + "/Rejected";
                                    else
                                        strPrintStatusId = "Rejected";
                                }

                                if (chkbxFilterStatusPendingApproval.Checked)
                                {
                                    if (strPrintStatusId.Length > 0)
                                        strPrintStatusId = strPrintStatusId + "/Pending Approval";
                                    else
                                        strPrintStatusId = "Pending Approval";
                                }
                            }
                            else
                                strPrintStatusId = "All Status";

                            if (txtFilterDateFrom.Text.Length > 0 && txtFilterDateTo.Text.Length > 0)
                                strPrintCreateDate = "Between " + txtFilterDateFrom.Text + " And " + txtFilterDateTo.Text;
                            else
                                strPrintCreateDate = "All Dates";

                            // gridview css
                            grdvwListing.HeaderRow.Style.Add("background-color", "Gray");
                            grdvwListing.HeaderRow.Style.Add("font-family", "Arial");
                            grdvwListing.HeaderRow.Style.Add("font-weight", "bold");
                            //grdvwListing.HeaderRow.Style.Add("font-size", "7px");
                            grdvwListing.HeaderRow.Style.Add("color", "White");
                            grdvwListing.HeaderRow.Style.Add("text-align", "center");
                            grdvwListing.Attributes.CssStyle.Add("font-size", "7px");
                            grdvwListing.RenderControl(hw);

                            StringReader sr = new StringReader(sw.ToString());
                            Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                            pdfDoc.Open();

                            // create table to pdf
                            PdfPTable table = new PdfPTable(3);
                            table.TotalWidth = 1000f;
                            table.LockedWidth = true;
                            table.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPCell cell = new PdfPCell(new Phrase("LIST OF E-SUBMISSIONS", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.UNDERLINE, iTextSharp.text.Color.BLACK)));
                            cell.Border = 0;
                            cell.Colspan = 3;
                            cell.HorizontalAlignment = 0;
                            table.AddCell(cell);

                            PdfPCell cell2 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell2.Border = 0;
                            cell2.Colspan = 3;
                            cell2.HorizontalAlignment = 0;
                            table.AddCell(cell2);

                            PdfPCell cell5 = new PdfPCell(new Phrase("RPT_ID : " + strPrintRptId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell5.Border = 0;
                            cell5.Colspan = 3;
                            cell5.HorizontalAlignment = 0;
                            table.AddCell(cell5);

                            PdfPCell cell6 = new PdfPCell(new Phrase("RPT_NAME : " + strPrintRptName, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell6.Border = 0;
                            cell6.Colspan = 3;
                            cell6.HorizontalAlignment = 0;
                            table.AddCell(cell6);

                            PdfPCell cell7 = new PdfPCell(new Phrase("REGULATOR_ID : " + strPrintRegulatorId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell7.Border = 0;
                            cell7.Colspan = 3;
                            cell7.HorizontalAlignment = 0;
                            table.AddCell(cell7);

                            PdfPCell cell8 = new PdfPCell(new Phrase("SREF : " + strPrintSREF, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell8.Border = 0;
                            cell8.Colspan = 3;
                            cell8.HorizontalAlignment = 0;
                            table.AddCell(cell8);

                            PdfPCell cell9 = new PdfPCell(new Phrase("FREQUENCY_ID : " + strPrintFrequencyId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell9.Border = 0;
                            cell9.Colspan = 3;
                            cell9.HorizontalAlignment = 0;
                            table.AddCell(cell9);

                            PdfPCell cell10 = new PdfPCell(new Phrase("STATUS_ID : " + strPrintStatusId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell10.Border = 0;
                            cell10.Colspan = 3;
                            cell10.HorizontalAlignment = 0;
                            table.AddCell(cell10);

                            PdfPCell cell11 = new PdfPCell(new Phrase("CREATE_DATE : " + strPrintCreateDate, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell11.Border = 0;
                            cell11.Colspan = 3;
                            cell11.HorizontalAlignment = 0;
                            table.AddCell(cell11);

                            PdfPCell cell3 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell3.Border = 0;
                            cell3.Colspan = 3;
                            cell3.HorizontalAlignment = 0;
                            table.AddCell(cell3);
                            pdfDoc.Add(table);

                            htmlparser.Parse(sr);
                            pdfDoc.Close();

                            Response.ContentType = "application/pdf";
                            Response.AddHeader("content-disposition", "attachment;filename=ListOfESubmissions.pdf");
                            Response.Cache.SetCacheability(HttpCacheability.NoCache);
                            Response.Write(pdfDoc);
                            Response.End();
                        }
                    }
                }
                else
                {
                    ShowMessage("There is no data to print", string.Empty);
                }
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "ESubmission.btnPrint_OnClick.ThreadAbortException", ex3.Message, Session["strUserId"].ToString());
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "ESubmission.btnPrint_OnClick.Exception", ex2.Message, Session["strUserId"].ToString());
            }
        }

        protected void btnExport_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=ListOfESubmissions.CSV");
                    Response.Charset = "";
                    Response.ContentType = "application/text";
                    Response.ContentEncoding = Encoding.UTF8;

                    //To Export all pages
                    grdvwListing.AllowPaging = false;
                    grdvwListing.AutoGenerateSelectButton = false;

                    // get data from gridview
                    this.fnBindListing(true);

                    StringBuilder sb = new StringBuilder();

                    for (int k = 0; k < grdvwListing.HeaderRow.Cells.Count; k++)
                    {
                        //add separator
                        sb.Append('"' + grdvwListing.HeaderRow.Cells[k].Text + '"' + ',');
                    }

                    //append new line
                    sb.Append("\r\n");

                    string val = string.Empty;

                    for (int i = 0; i < grdvwListing.Rows.Count; i++)
                    {
                        for (int k = 0; k < grdvwListing.Rows[i].Cells.Count; k++)  //skip "select"/row_id
                        {
                            val = HttpUtility.HtmlDecode(grdvwListing.Rows[i].Cells[k].Text);
                            val = BusinessLogicClass.fnRemoveIllegalCharFromGrid(val);

                            if (val == "&nbsp;")
                                val = "";

                            if (val.Contains("&#"))
                                val = BusinessLogicClass.fnRemoveIllegalNonHTMLCharFromGrid(val);

                            //to avoid Â
                            if (val.Trim() == "")
                                sb.Append(',');
                            else
                            {
                                val = "\t" + val;   //to maintain leading zeros
                                sb.Append('"' + val + '"' + ',');
                            }
                        }

                        //append new line
                        sb.Append("\r\n");
                    }

                    Response.Output.Write(sb.ToString());

                    //Response.Flush();
                    //Response.End();

                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                }
                else
                {
                    ShowMessage("There is no data to export", string.Empty);
                }
            }
            catch (System.OutOfMemoryException ex4)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex4.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex3.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex2.Message, Session["strUserId"].ToString());    //12 as default err code
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
        }

        #endregion
    }
}