﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RRFGUI.Library;
using System.Data;

namespace RRFGUI.Maintenance
{
    public partial class show_attachment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sRowNum = Request.QueryString["RowNum"].ToString();

            //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT + resubmission attachments
            string sAttachType = Request.QueryString["AttachType"].ToString();
            string sRecNo = Request.QueryString["RecNo"].ToString();

            if (!IsPostBack)
            {
                DataTable dtCodeDetails = BusinessLogicClass.fnLoadESubmissionAttachment(sRowNum, sAttachType, sRecNo, Session["strUserId"].ToString());

                if (dtCodeDetails.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtCodeDetails.Rows)
                    {
                        //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT + resubmission attachments
                        //Response.BinaryWrite((byte[])dr["EXTENDED_ATTACHMENT_DATA"]);

                        if (dr["ATTACHMENT_DATA"] != System.DBNull.Value)
                            Response.BinaryWrite((byte[])dr["ATTACHMENT_DATA"]);
                        else
                            Response.Write("No Data!");
                    }
                }
            }
        }
    }
}